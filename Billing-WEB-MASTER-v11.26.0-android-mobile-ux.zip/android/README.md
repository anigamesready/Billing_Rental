# Android build — V11.26.0

This Android wrapper opens the same V11.26 web UI packaged in `app/src/main/assets/web/`.

The wrapper is intentionally presentation-only: timer, expiry, API, authentication and business logic stay in the web files.

Build with a standard Android SDK + Gradle/Android Gradle Plugin 8.7.3 environment:

```text
cd android
./gradlew assembleRelease
```

The resulting APK is under `android/app/build/outputs/apk/release/`.
