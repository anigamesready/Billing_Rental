
        const APP_VERSION = 'V11.0.0-CLOUD-OFFLINE-FIRST';
        const ADMIN_PIN = "irfani";
        const ADMIN_CUSTOM_PIN_KEY = 'billing_admin_custom_pin_v10';

        const ADMIN_CUSTOM_PIN_HASH_KEY = 'billing_admin_custom_pin_hash_v10';

        function getAdminPins() {
            // Password custom diverifikasi lewat hash. Password default tetap menjadi recovery.
            return [ADMIN_PIN];
        }

        async function hashAdminPin(value) {
            const text = new TextEncoder().encode(String(value));
            const digest = await crypto.subtle.digest('SHA-256', text);
            return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('');
        }

        const DEFAULT_DB_USERS = {
            "AGR1": { category: "reguler", remainingSeconds: 7200, expiryDate: "" },
            "REG100": { category: "reguler", remainingSeconds: 7200, expiryDate: "" },
            "WEEKLY01": { category: "mingguan", remainingSeconds: 36000, expiryDate: getFutureDate(7) },
            "MONTHLY01": { category: "bulanan", remainingSeconds: 180000, expiryDate: getFutureDate(30) }
        };

        function loadDB() {
            try {
                const raw = localStorage.getItem('billing_db_users');
                if (!raw) return DEFAULT_DB_USERS;
                const parsed = JSON.parse(raw);
                if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) throw new Error('Format database tidak valid');

                for (const [code, user] of Object.entries(parsed)) {
                    if (!user || typeof user !== 'object') delete parsed[code];
                    else user.remainingSeconds = Math.max(0, Number(user.remainingSeconds) || 0);
                }
                return parsed;
            } catch (error) {
                console.error('Database billing rusak, memakai data default:', error);
                localStorage.removeItem('billing_db_users');
                return DEFAULT_DB_USERS;
            }
        }

        let dbUsers = loadDB();

        let currentActiveCode = null;
        let timerInterval = null;
        let timerDeadlineMs = null;
        let timerCompact = false;
        let lastSavedRemaining = null;
        const ACTIVE_SESSION_KEY = 'billing_active_session_v10';
        const TEST_SESSION_CODE = '__TEST10__';
        const AUTO_BACKUP_META_KEY = 'billing_auto_backup_meta_v10';
        const SYSTEM_LOG_KEY = 'billing_system_log_v10';
        let autoBackupBusy = false;

        // V11 cloud bridge reads state through these explicit helpers.
        window.v11GetActiveCode = () => currentActiveCode;
        window.v11GetUser = (code) => dbUsers?.[String(code || '').toUpperCase()] || null;
        window.v11ApplyRemoteCommand = (command, payload = {}) => {
            const cmd = String(command || '');
            try {
                if (cmd === 'add_time') {
                    const seconds = Math.max(0, Number(payload.seconds || 0));
                    const code = currentActiveCode || String(payload.code || '').toUpperCase();
                    if (!code || !dbUsers[code]) return { ok: false, message: 'Kode rental tidak ditemukan.' };
                    if (code === currentActiveCode && timerDeadlineMs) {
                        timerDeadlineMs += seconds * 1000;
                        dbUsers[code].remainingSeconds = Math.ceil((timerDeadlineMs - Date.now()) / 1000);
                        persistActiveSession();
                    } else {
                        dbUsers[code].remainingSeconds = Math.max(0, Number(dbUsers[code].remainingSeconds) || 0) + seconds;
                    }
                    saveDB(); updateTimerDisplay();
                    return { ok: true, message: `Tambah ${Math.round(seconds / 60)} menit.` };
                }
                if (cmd === 'pause') { if (!currentActiveCode) return { ok:false, message:'Tidak ada sesi aktif.' }; pauseActiveSession(); return { ok: true, message: 'Sesi dijeda.' }; }
                if (cmd === 'stop' || cmd === 'logout') { stopActiveSession(); return { ok: true, message: 'Sesi dihentikan/dikeluarkan.' }; }
                if (cmd === 'start_trial') { if (currentActiveCode || localStorage.getItem('billing_remote_paused_code')) return { ok:false, message:'PC masih memiliki sesi aktif/jeda.' }; startTenMinuteTest(); return { ok:true, message:'Free test 10 menit dimulai.' }; }
                if (cmd === 'resume') {
                    const code = currentActiveCode || String(payload.code || localStorage.getItem('billing_remote_paused_code') || '').toUpperCase();
                    if (!code || !dbUsers[code]) return { ok: false, message: 'Tidak ada sesi aktif untuk dilanjutkan.' };
                    const ok = resumePausedSession(code);
                    return ok === true ? { ok: true, message: 'Sesi dilanjutkan.' } : { ok: false, message: 'Sesi tidak dapat dilanjutkan.' };
                }
                if (cmd === 'restart_billing') { persistActiveSession(); saveDB(); const r = window.electronAPI?.restartBilling?.(); return r?.ok===false ? r : { ok: true }; }
                if (cmd === 'restart_pc') { persistActiveSession(); saveDB(); window.electronAPI?.powerAction?.('restart'); return { ok: true }; }
                if (cmd === 'shutdown') { persistActiveSession(); saveDB(); window.electronAPI?.powerAction?.('shutdown'); return { ok: true }; }
                if (cmd === 'logoff') { persistActiveSession(); saveDB(); window.electronAPI?.powerAction?.('logoff'); return { ok: true }; }
                if (cmd === 'refresh') { location.reload(); return { ok: true }; }
                if (cmd === 'upsert_rental') {
                    const code = String(payload.code||'').toUpperCase();
                    if (!code) return { ok:false, message:'Kode rental kosong.' };
                    const incoming = Math.max(0, Number(payload.remainingSeconds)||0);
                    const existing = dbUsers[code];
                    dbUsers[code] = {...(existing||{}), category: payload.category || existing?.category || 'reguler', remainingSeconds: incoming, expiryDate: payload.expiryDate || existing?.expiryDate || ''};
                    saveDB(); renderUserTable();
                    return { ok:true, message:'Data rental tersinkron.', code };
                }
                if (cmd === 'set_theme' && payload.themeId) {
                    const theme = themes.find(item => item.id === payload.themeId);
                    if (theme) { applyTheme(theme); return { ok: true };
                    }
                }
                return { ok: false, message: 'Perintah belum didukung pada state saat ini.' };
            } catch (error) { return { ok: false, message: error.message }; }
        };

        function writeSystemLog(message, level = 'INFO') {
            try {
                const logs = JSON.parse(localStorage.getItem(SYSTEM_LOG_KEY) || '[]');
                logs.push({ time: new Date().toISOString(), level, message: String(message) });
                while (logs.length > 150) logs.shift();
                localStorage.setItem(SYSTEM_LOG_KEY, JSON.stringify(logs));
            } catch (e) { console.warn('Gagal menyimpan log sistem:', e); }
        }

        function persistActiveSession() {
            if (!currentActiveCode || !timerDeadlineMs) return;
            localStorage.setItem(ACTIVE_SESSION_KEY, JSON.stringify({
                code: currentActiveCode,
                deadlineMs: timerDeadlineMs,
                savedAt: Date.now()
            }));
        }

        function clearPersistedActiveSession() {
            localStorage.removeItem(ACTIVE_SESSION_KEY);
        }

        // Simpan database billing ke localStorage. Fungsi ini wajib tersedia
        // agar countdown dan tombol stop tidak terhenti karena JavaScript error.
        function saveDB() {
            try {
                localStorage.setItem('billing_db_users', JSON.stringify(dbUsers));
                scheduleAutoBackup();
            } catch (error) {
                console.error('Gagal menyimpan database billing:', error);
                writeSystemLog('Gagal menyimpan database billing: ' + error.message, 'ERROR');
            }
        }

        function collectLocalBackup() {
            const snapshot = {};
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                if (key && key !== AUTO_BACKUP_META_KEY) snapshot[key] = localStorage.getItem(key);
            }
            return {
                format: 'ani-games-billing-v10-backup',
                version: 1,
                createdAt: new Date().toISOString(),
                note: 'Backup konfigurasi lokal. Media video/GIF di IndexedDB tidak disalin ke file JSON.',
                localStorage: snapshot
            };
        }

        async function saveBackupToDisk(manual = false) {
            if (!window.electronAPI?.writeBackup) return false;
            if (autoBackupBusy && !manual) return false;
            autoBackupBusy = true;
            try {
                const result = await window.electronAPI.writeBackup(collectLocalBackup());
                if (result?.ok) {
                    localStorage.setItem(AUTO_BACKUP_META_KEY, JSON.stringify({ lastAt: Date.now(), path: result.path || '' }));
                    const status = document.getElementById('backup-status');
                    if (status) status.textContent = `Backup terakhir: ${new Date().toLocaleString('id-ID')}`;
                    writeSystemLog((manual ? 'Backup manual' : 'Backup otomatis') + ' berhasil.');
                } else if (manual) {
                    showCustomModal(result?.message || 'Backup gagal dibuat.', 'BACKUP GAGAL', true, '⚠️');
                }
                return Boolean(result?.ok);
            } catch (error) {
                writeSystemLog('Backup gagal: ' + error.message, 'ERROR');
                if (manual) showCustomModal('Backup gagal: ' + error.message, 'BACKUP GAGAL', true, '⚠️');
                return false;
            } finally { autoBackupBusy = false; }
        }

        let autoBackupTimer = null;
        function scheduleAutoBackup() {
            let meta = {};
            try { meta = JSON.parse(localStorage.getItem(AUTO_BACKUP_META_KEY) || '{}'); } catch (_) {}
            const elapsed = Date.now() - Number(meta.lastAt || 0);
            if (elapsed < 10 * 60 * 1000) return;
            if (autoBackupTimer) return;
            autoBackupTimer = window.setTimeout(async () => {
                autoBackupTimer = null;
                await saveBackupToDisk(false);
            }, 250);
        }

        function startAutoBackupWatcher() {
            window.setInterval(() => {
                if (document.visibilityState === 'hidden') return;
                scheduleAutoBackup();
            }, 60 * 1000);
        }

        async function createManualBackup() {
            await saveBackupToDisk(true);
        }

        async function restoreManualBackup() {
            if (!window.electronAPI?.restoreBackup) return showCustomModal('Fungsi restore belum tersedia.', 'ERROR', true, '⚠️');
            if (!confirm('Restore backup akan mengganti data konfigurasi lokal. Lanjutkan?')) return;
            try {
                const result = await window.electronAPI.restoreBackup();
                if (!result?.ok) {
                    if (result?.cancelled) return;
                    return showCustomModal(result?.message || 'Restore gagal.', 'RESTORE GAGAL', true, '⚠️');
                }
                const backup = result.data;
                if (!backup || backup.format !== 'ani-games-billing-v10-backup' || !backup.localStorage) {
                    return showCustomModal('File backup tidak dikenali sebagai backup V10.', 'BACKUP TIDAK VALID', true, '⚠️');
                }
                const backupKeys = new Set(Object.keys(backup.localStorage));
                for (let i = localStorage.length - 1; i >= 0; i--) {
                    const key = localStorage.key(i);
                    if (key && !backupKeys.has(key)) localStorage.removeItem(key);
                }
                for (const [key, value] of Object.entries(backup.localStorage)) localStorage.setItem(key, value);
                writeSystemLog('Restore backup berhasil. Billing akan direstart untuk menerapkan data.');
                showCustomModal('Restore berhasil. Billing akan dibuka ulang agar data diterapkan.', 'RESTORE BERHASIL', false, '♻️');
                setTimeout(() => restartBillingApp(true, true), 700);
            } catch (error) {
                writeSystemLog('Restore gagal: ' + error.message, 'ERROR');
                showCustomModal('Restore gagal: ' + error.message, 'RESTORE GAGAL', true, '⚠️');
            }
        }

        async function collectThemeMediaForBackup() {
            const items = [];
            try {
                const db = await openThemeMediaDB();
                const mediaKeys = await new Promise((resolve, reject) => {
                    const tx = db.transaction('media', 'readonly');
                    const req = tx.objectStore('media').getAllKeys();
                    req.onsuccess = () => resolve(req.result || []);
                    req.onerror = () => reject(req.error);
                });
                for (const key of mediaKeys) {
                    const blob = await getThemeMedia(key);
                    if (!blob) continue;
                    items.push({ key: String(key), type: blob.type || 'application/octet-stream', name: String(key), size: blob.size, data: await blob.arrayBuffer() });
                }
                const assetKeys = await new Promise((resolve, reject) => {
                    const tx = db.transaction('assets', 'readonly');
                    const req = tx.objectStore('assets').getAllKeys();
                    req.onsuccess = () => resolve(req.result || []);
                    req.onerror = () => reject(req.error);
                });
                for (const key of assetKeys) {
                    const blob = await getThemeAsset(key);
                    if (!blob) continue;
                    items.push({ key: String(key), type: blob.type || 'application/octet-stream', name: String(key), size: blob.size, data: await blob.arrayBuffer() });
                }
            } catch (error) { writeSystemLog('Pembacaan media backup gagal: ' + error.message, 'ERROR'); }
            return items;
        }

        async function createFullBackup() {
            if (!window.electronAPI?.startFullBackup) return showCustomModal('Backup lengkap belum tersedia.', 'ERROR', true, '⚠️');
            try {
                showCustomModal('Sedang membuat backup lengkap. Jangan tutup Billing sampai selesai.', 'BACKUP LENGKAP', false, '🗄️');
                const media = await collectThemeMediaForBackup();
                const start = await window.electronAPI.startFullBackup({
                    format: 'ani-games-billing-v10-full-backup',
                    config: collectLocalBackup()
                });
                if (!start?.ok) return showCustomModal(start?.message || 'Backup lengkap gagal dimulai.', 'BACKUP GAGAL', true, '⚠️');
                const manifestMedia = [];
                for (let i = 0; i < media.length; i++) {
                    const item = media[i];
                    const result = await window.electronAPI.writeFullBackupMedia({ root: start.path, index: i, item });
                    if (!result?.ok) throw new Error(result?.message || `Media ${item.key} gagal disalin.`);
                    manifestMedia.push({ key: item.key, file: result.file, type: item.type, name: item.name, size: item.size });
                    const status = document.getElementById('backup-status');
                    if (status) status.textContent = `Backup media ${i + 1}/${media.length}...`;
                }
                const done = await window.electronAPI.finishFullBackup({ root: start.path, media: manifestMedia });
                if (!done?.ok) throw new Error(done?.message || 'Manifest backup gagal dibuat.');
                writeSystemLog(`Backup lengkap berhasil. Media: ${done.mediaCount || 0}.`);
                const status = document.getElementById('backup-status');
                if (status) status.textContent = `Backup lengkap terakhir: ${new Date().toLocaleString('id-ID')}`;
                showCustomModal(`Backup lengkap berhasil dibuat.\nMedia tersalin: ${done.mediaCount || 0}.`, 'BACKUP LENGKAP BERHASIL', false, '✅');
            } catch (error) {
                writeSystemLog('Backup lengkap gagal: ' + error.message, 'ERROR');
                showCustomModal('Backup lengkap gagal: ' + error.message, 'BACKUP GAGAL', true, '⚠️');
            }
        }

        async function restoreFullBackup() {
            if (!window.electronAPI?.restoreFullBackup) return showCustomModal('Restore lengkap belum tersedia.', 'ERROR', true, '⚠️');
            if (!confirm('Restore lengkap akan mengganti konfigurasi dan media lokal. Lanjutkan?')) return;
            try {
                const result = await window.electronAPI.restoreFullBackup();
                if (!result?.ok) { if (result?.cancelled) return; return showCustomModal(result?.message || 'Restore lengkap gagal.', 'RESTORE GAGAL', true, '⚠️'); }
                const backup = result;
                if (!backup.config || !backup.config.localStorage || backup.manifest?.format !== 'ani-games-billing-v10-full-backup') throw new Error('Backup lengkap tidak valid.');
                const fullBackupKeys = new Set(Object.keys(backup.config.localStorage));
                for (let i = localStorage.length - 1; i >= 0; i--) {
                    const key = localStorage.key(i);
                    if (key && !fullBackupKeys.has(key)) localStorage.removeItem(key);
                }
                for (const [key, value] of Object.entries(backup.config.localStorage)) localStorage.setItem(key, value);
                await openThemeMediaDB();
                for (const item of (backup.manifest.media || [])) {
                    const absolute = `${backup.root.replace(/[\\/]$/, '')}/${item.file.replace(/\\/g, '/')}`;
                    const fileResult = await window.electronAPI.readBackupFile(absolute);
                    if (!fileResult?.ok) throw new Error(fileResult?.message || `Media ${item.key} gagal dibaca.`);
                    const blob = new Blob([fileResult.data], { type: item.type || 'application/octet-stream' });
                    if (String(item.key).startsWith('theme-media-')) await putThemeMedia(item.key, blob);
                    else await putThemeAsset(item.key, blob);
                }
                writeSystemLog('Restore backup lengkap berhasil. Billing akan direstart.');
                showCustomModal('Restore lengkap berhasil. Billing akan dibuka ulang.', 'RESTORE BERHASIL', false, '♻️');
                setTimeout(() => restartBillingApp(true, true), 700);
            } catch (error) {
                writeSystemLog('Restore lengkap gagal: ' + error.message, 'ERROR');
                showCustomModal('Restore lengkap gagal: ' + error.message, 'RESTORE GAGAL', true, '⚠️');
            }
        }

        function showSystemLog() {
            try {
                const logs = JSON.parse(localStorage.getItem(SYSTEM_LOG_KEY) || '[]');
                const recent = logs.slice(-20).reverse();
                const text = recent.length ? recent.map(x => `${new Date(x.time).toLocaleString('id-ID')} [${x.level}] ${x.message}`).join('\n') : 'Belum ada log.';
                showCustomModal(text, 'LOG SISTEM TERAKHIR', false, '📋');
            } catch (error) {
                showCustomModal('Log sistem tidak dapat dibaca.', 'ERROR', true, '⚠️');
            }
        }

        function syncTimerWindowSize() {
            // V11.4.2: jangan resize Electron window saat sesi aktif.
            // Billing tetap fullscreen/login; timer hanyalah overlay floating di dalamnya.
            return;
        }

        function minimizeTimerWindow(event) {
            if (event) { event.preventDefault(); event.stopPropagation(); }

            const widget = document.getElementById('timer-widget');
            if (!widget || widget.classList.contains('hidden')) return;

            timerCompact = !timerCompact;
            widget.classList.toggle('compact', timerCompact);

            const button = document.getElementById('timer-minimize');
            if (button) {
                button.innerText = timerCompact ? '+' : '−';
                button.title = timerCompact
                    ? 'Kembalikan ukuran timer'
                    : 'Kecilkan timer menjadi popup';
            }

            requestAnimationFrame(() => syncTimerWindowSize());
        }

        function pauseStopSessionFromTimer(event) {
            if (event) { event.preventDefault(); event.stopPropagation(); }
            stopActiveSession();
        }

        function finishSessionFromTimer(event) {
            if (event) { event.preventDefault(); event.stopPropagation(); }
            stopActiveSession();
        }

        function initTimerDragging() {
            const pauseButton = document.getElementById('timer-pause-stop');
            const minimizeButton = document.getElementById('timer-minimize');
            const finishButton = document.getElementById('timer-finish');

            if (pauseButton) {
                pauseButton.addEventListener('pointerdown', (e) => e.stopPropagation());
                pauseButton.addEventListener('click', pauseStopSessionFromTimer);
            }
            if (minimizeButton) {
                minimizeButton.addEventListener('pointerdown', (e) => e.stopPropagation());
                minimizeButton.addEventListener('click', minimizeTimerWindow);
            }
            if (finishButton) {
                finishButton.addEventListener('pointerdown', (e) => e.stopPropagation());
                finishButton.addEventListener('click', finishSessionFromTimer);
            }
        }

        window.addEventListener('resize', () => {
            if (document.getElementById('timer-widget')?.classList.contains('hidden')) return;
            syncTimerWindowSize();
        });

        // Saat kembali ke halaman login, pulihkan fokus keyboard secara aman.
        // Ini mencegah kondisi Electron aktif tetapi input tidak menerima ketikan.
        window.addEventListener('focus', () => {
            if (!document.getElementById('lock-screen').classList.contains('hidden')) {
                focusLoginInput();
            }
        });

        document.addEventListener('visibilitychange', () => {
            if (!document.hidden && !document.getElementById('lock-screen').classList.contains('hidden')) {
                focusLoginInput();
            }
        });

        document.getElementById('user-code-input').addEventListener('click', focusLoginInput);
        document.getElementById('user-code-input').addEventListener('pointerup', focusLoginInput);

        function getFutureDate(days) {
            let d = new Date();
            d.setDate(d.getDate() + days);
            return d.toISOString().slice(0, 16);
        }

        function showCustomModal(message, title = "PEMBERITAHUAN", isAlert = true, icon = "⚠️") {
            const modal = document.getElementById('custom-modal');
            const box = document.getElementById('modal-card-box');
            document.getElementById('modal-title').innerText = title;
            document.getElementById('modal-message').innerText = message;
            document.getElementById('modal-icon').innerText = icon;

            if (isAlert) box.classList.add('modal-alert');
            else box.classList.remove('modal-alert');

            modal.classList.remove('hidden');
        }

        function closeCustomModal() {
            document.getElementById('custom-modal').classList.add('hidden');
        }

        /* --- FUNGSI AUTH ADMIN VIA CUSTOM MODAL --- */
        function openAdminAuth() {
            document.getElementById('admin-pin-input').value = '';
            document.getElementById('admin-login-modal').classList.remove('hidden');
            focusAdminPinInput();
        }

        function focusLoginInput() {
            const input = document.getElementById('user-code-input');
            if (!input || document.getElementById('lock-screen').classList.contains('hidden')) return;

            // Pastikan window/renderer sudah aktif sebelum meminta fokus keyboard.
            try { window.focus(); } catch (e) {}
            requestAnimationFrame(() => {
                input.focus({ preventScroll: true });
                try {
                    const len = input.value.length;
                    input.setSelectionRange(len, len);
                } catch (e) {}
            });
        }

        function focusAdminPinInput() {
            const input = document.getElementById('admin-pin-input');
            if (!input || document.getElementById('admin-login-modal').classList.contains('hidden')) return;
            try { window.focus(); } catch (e) {}
            requestAnimationFrame(() => input.focus({ preventScroll: true }));
        }

        function closeAdminAuth() {
            document.getElementById('admin-login-modal').classList.add('hidden');
        }

        async function submitAdminAuth() {
            const inputPin = document.getElementById('admin-pin-input').value.trim();
            let valid = inputPin === ADMIN_PIN;
            try {
                const storedHash = localStorage.getItem(ADMIN_CUSTOM_PIN_HASH_KEY);
                if (storedHash) valid = valid || (await hashAdminPin(inputPin)) === storedHash;
                else {
                    // Kompatibilitas build lama: migrasikan password plaintext sekali setelah login sukses.
                    const legacy = localStorage.getItem(ADMIN_CUSTOM_PIN_KEY);
                    if (legacy && inputPin === legacy) {
                        localStorage.setItem(ADMIN_CUSTOM_PIN_HASH_KEY, await hashAdminPin(legacy));
                        localStorage.removeItem(ADMIN_CUSTOM_PIN_KEY);
                        valid = true;
                    }
                }
            } catch (e) {
                valid = getAdminPins().includes(inputPin);
            }
            if (valid) {
                closeAdminAuth();
                renderUserTable();
                renderThemeList();
                document.getElementById('admin-panel').classList.remove('hidden');
            } else {
                closeAdminAuth();
                showCustomModal("PIN Admin Salah!", "AKSES DITOLAK", true, "🔒");
            }
        }

        document.getElementById('admin-pin-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') submitAdminAuth();
        });


        /* --- V10 THEME MANAGER --- */
        const THEME_STORAGE_KEY = 'billing_themes_v10';
        const ACTIVE_THEME_KEY = 'billing_active_theme_v10';
        const DEFAULT_LOGO_SRC = 'icon/logo.png';

        const BUILTIN_THEMES = [
            {
                id: 'default',
                name: 'Default Cyber',
                brandTitle: 'ANI GAMES READY',
                brandSubtitle: 'ANYWHERE ANYTIME',
                primary: '#00f2fe',
                secondary: '#a855f7',
                card: '#121829',
                backgroundImage: '',
                backgroundCss: 'linear-gradient(135deg, #070913 0%, #111827 55%, #1e1033 100%)',
                logoData: ''
            },
            {
                id: 'neon-red',
                name: 'Gaming Red',
                brandTitle: 'ANI GAMES READY',
                brandSubtitle: 'GAMING RENTAL',
                primary: '#ff3b30',
                secondary: '#ff8a00',
                card: '#241116',
                backgroundImage: '',
                backgroundCss: 'linear-gradient(135deg, #090909 0%, #2a0b12 55%, #190d05 100%)',
                logoData: ''
            },
            {
                id: 'cyber-blue',
                name: 'Cyber Blue',
                brandTitle: 'ANI GAMES READY',
                brandSubtitle: 'PLAY • RENT • REPEAT',
                primary: '#38bdf8',
                secondary: '#2563eb',
                card: '#0b1728',
                backgroundImage: '',
                backgroundCss: 'linear-gradient(135deg, #020617 0%, #082f49 55%, #172554 100%)',
                logoData: ''
            },
            {
                id: 'purple-night',
                name: 'Purple Night',
                brandTitle: 'ANI GAMES READY',
                brandSubtitle: 'PREMIUM GAMING',
                primary: '#c084fc',
                secondary: '#7c3aed',
                card: '#1b1230',
                backgroundImage: '',
                backgroundCss: 'linear-gradient(135deg, #08060f 0%, #21103a 55%, #120d2d 100%)',
                logoData: ''
            }
        ];

        let editingThemeId = null;
        let themeBackgroundData = '';
        let themeLogoData = '';
        let themeWallpaperData = '';
        let themeBackgroundMediaFile = null;
        let themeBackgroundMediaObjectUrl = '';
        let themeBackgroundMediaCleared = false;
        let activeBackgroundObjectUrl = '';
        let backgroundMediaDbReady = null;
        let themeAssetMigrationPromise = null;
        const THEME_MEDIA_ENABLED_KEY = 'billing_theme_media_enabled_v10';

        function isThemeMediaEnabled() {
            return localStorage.getItem(THEME_MEDIA_ENABLED_KEY) !== '0';
        }

        function setThemeMediaEnabled(enabled) {
            localStorage.setItem(THEME_MEDIA_ENABLED_KEY, enabled ? '1' : '0');
        }

        function releaseActiveBackgroundMedia() {
            const oldVideo = document.getElementById('theme-background-video');
            if (oldVideo) {
                try { oldVideo.pause(); } catch (e) {}
                try { oldVideo.removeAttribute('src'); oldVideo.load(); } catch (e) {}
                oldVideo.remove();
            }
            const oldGif = document.getElementById('theme-background-gif');
            if (oldGif) oldGif.remove();
            clearActiveMediaObjectUrl();
        }


        function openThemeMediaDB() {
            if (backgroundMediaDbReady) return backgroundMediaDbReady;
            backgroundMediaDbReady = new Promise((resolve, reject) => {
                try {
                    const req = indexedDB.open('ani_games_theme_media_v10', 2);
                    req.onupgradeneeded = () => {
                        const db = req.result;
                        if (!db.objectStoreNames.contains('media')) db.createObjectStore('media');
                        if (!db.objectStoreNames.contains('assets')) db.createObjectStore('assets');
                    };
                    req.onsuccess = () => resolve(req.result);
                    req.onerror = () => reject(req.error || new Error('Gagal membuka penyimpanan media.'));
                } catch (error) { reject(error); }
            });
            return backgroundMediaDbReady;
        }

        async function putThemeMedia(key, file) {
            if (!file) return;
            try {
                const db = await openThemeMediaDB();
                await new Promise((resolve, reject) => {
                    const tx = db.transaction('media', 'readwrite');
                    tx.objectStore('media').put(file, key);
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error || new Error('Gagal menyimpan media.'));
                });
            } catch (error) {
                console.error('Media tema gagal disimpan:', error);
            }
        }

        async function getThemeMedia(key) {
            try {
                const db = await openThemeMediaDB();
                return await new Promise((resolve, reject) => {
                    const tx = db.transaction('media', 'readonly');
                    const req = tx.objectStore('media').get(key);
                    req.onsuccess = () => resolve(req.result || null);
                    req.onerror = () => reject(req.error);
                });
            } catch (error) {
                console.error('Media tema gagal dibaca:', error);
                return null;
            }
        }

        function dataUrlToBlob(dataUrl) {
            const match = String(dataUrl || '').match(/^data:([^;,]+)(?:;charset=[^;,]+)?;base64,(.+)$/);
            if (!match) throw new Error('Data gambar tidak valid.');
            const binary = atob(match[2]);
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            return new Blob([bytes], { type: match[1] || 'application/octet-stream' });
        }

        async function putThemeAsset(key, dataUrlOrBlob) {
            if (!key || !dataUrlOrBlob) return false;
            try {
                const blob = typeof dataUrlOrBlob === 'string' ? dataUrlToBlob(dataUrlOrBlob) : dataUrlOrBlob;
                const db = await openThemeMediaDB();
                await new Promise((resolve, reject) => {
                    const tx = db.transaction('assets', 'readwrite');
                    tx.objectStore('assets').put(blob, key);
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error || new Error('Gagal menyimpan asset.'));
                });
                return true;
            } catch (error) {
                console.error('Asset tema gagal disimpan:', error);
                return false;
            }
        }

        async function getThemeAsset(key) {
            if (!key) return null;
            try {
                const db = await openThemeMediaDB();
                return await new Promise((resolve, reject) => {
                    const tx = db.transaction('assets', 'readonly');
                    const req = tx.objectStore('assets').get(key);
                    req.onsuccess = () => resolve(req.result || null);
                    req.onerror = () => reject(req.error);
                });
            } catch (error) { return null; }
        }

        async function deleteThemeAsset(key) {
            if (!key) return;
            try {
                const db = await openThemeMediaDB();
                await new Promise((resolve, reject) => {
                    const tx = db.transaction('assets', 'readwrite');
                    tx.objectStore('assets').delete(key);
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error);
                });
            } catch (error) { console.error('Asset tema gagal dihapus:', error); }
        }

        async function getThemeAssetDataUrl(key) {
            const blob = await getThemeAsset(key);
            if (!blob) return '';
            return await new Promise(resolve => {
                const reader = new FileReader();
                reader.onload = () => resolve(String(reader.result || ''));
                reader.onerror = () => resolve('');
                reader.readAsDataURL(blob);
            });
        }

        async function migrateLegacyThemeAssets() {
            if (themeAssetMigrationPromise) return themeAssetMigrationPromise;
            themeAssetMigrationPromise = (async () => {
                try {
                    await openThemeMediaDB();
                    let changed = false;
                    for (const theme of themes) {
                        if (!theme || BUILTIN_THEMES.some(b => b.id === theme.id)) continue;
                        if (theme.backgroundImage && !theme.backgroundAssetKey) {
                            const key = `theme-asset-bg-${theme.id}`;
                            if (await putThemeAsset(key, theme.backgroundImage)) { theme.backgroundAssetKey = key; theme.backgroundImage = ''; changed = true; }
                        }
                        if (theme.logoData && !theme.logoAssetKey) {
                            const key = `theme-asset-logo-${theme.id}`;
                            if (await putThemeAsset(key, theme.logoData)) { theme.logoAssetKey = key; theme.logoData = ''; changed = true; }
                        }
                        if (theme.desktopWallpaperData && !theme.wallpaperAssetKey) {
                            const key = `theme-asset-wallpaper-${theme.id}`;
                            if (await putThemeAsset(key, theme.desktopWallpaperData)) { theme.wallpaperAssetKey = key; theme.desktopWallpaperData = ''; changed = true; }
                        }
                    }
                    if (changed) saveThemes();
                    writeSystemLog('Migrasi media legacy selesai.');
                } catch (error) { writeSystemLog('Migrasi media legacy gagal: ' + error.message, 'ERROR'); }
            })();
            return themeAssetMigrationPromise;
        }

        async function deleteThemeMedia(key) {
            if (!key) return;
            try {
                const db = await openThemeMediaDB();
                await new Promise((resolve, reject) => {
                    const tx = db.transaction('media', 'readwrite');
                    tx.objectStore('media').delete(key);
                    tx.oncomplete = resolve;
                    tx.onerror = () => reject(tx.error);
                });
            } catch (error) { console.error('Media tema gagal dihapus:', error); }
        }

        function clearActiveMediaObjectUrl() {
            if (activeBackgroundObjectUrl) {
                try { URL.revokeObjectURL(activeBackgroundObjectUrl); } catch (e) {}
                activeBackgroundObjectUrl = '';
            }
        }

        async function saveAdminPassword() {
            const a = document.getElementById('admin-new-password').value;
            const b = document.getElementById('admin-new-password-confirm').value;
            if (!a || a.length < 4) return showCustomModal('Password baru minimal 4 karakter.', 'PASSWORD ADMIN', true, '🔐');
            if (a !== b) return showCustomModal('Konfirmasi password tidak sama.', 'PASSWORD ADMIN', true, '🔐');
            if (a === ADMIN_PIN) return showCustomModal('Gunakan password selain password default.', 'PASSWORD ADMIN', true, '🔐');
            try {
                localStorage.setItem(ADMIN_CUSTOM_PIN_HASH_KEY, await hashAdminPin(a));
                localStorage.removeItem(ADMIN_CUSTOM_PIN_KEY);
            } catch (e) {
                return showCustomModal('Password gagal diamankan: ' + e.message, 'PASSWORD ADMIN', true, '🔐');
            }
            document.getElementById('admin-new-password').value = '';
            document.getElementById('admin-new-password-confirm').value = '';
            showCustomModal('Password baru tersimpan. Password default tetap aktif sebagai recovery.', 'PASSWORD TERSIMPAN', false, '✅');
        }

        function resetAdminPassword() {
            localStorage.removeItem(ADMIN_CUSTOM_PIN_KEY);
            localStorage.removeItem(ADMIN_CUSTOM_PIN_HASH_KEY);
            document.getElementById('admin-new-password').value = '';
            document.getElementById('admin-new-password-confirm').value = '';
            showCustomModal('Password dikembalikan ke default. Password: irfani', 'PASSWORD DEFAULT', false, '🔄');
        }

        function cloneThemes(themes) {
            return themes.map(theme => ({ ...theme }));
        }

        function loadThemes() {
            try {
                const raw = localStorage.getItem(THEME_STORAGE_KEY);
                if (!raw) return cloneThemes(BUILTIN_THEMES);
                const parsed = JSON.parse(raw);
                if (!Array.isArray(parsed)) throw new Error('Format tema tidak valid');

                const byId = new Map();
                [...BUILTIN_THEMES, ...parsed].forEach(theme => {
                    if (theme && theme.id && theme.name) byId.set(String(theme.id), theme);
                });
                return [...byId.values()];
            } catch (error) {
                console.error('Database tema rusak, memakai tema bawaan:', error);
                return cloneThemes(BUILTIN_THEMES);
            }
        }

        let themes = loadThemes();

        function saveThemes() {
            const customThemes = themes.filter(theme => !BUILTIN_THEMES.some(b => b.id === theme.id));
            localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(customThemes));
        }

        function getActiveThemeId() {
            return localStorage.getItem(ACTIVE_THEME_KEY) || 'default';
        }

        function getActiveTheme() {
            return themes.find(theme => theme.id === getActiveThemeId()) || themes[0] || BUILTIN_THEMES[0];
        }

        function hexToRgba(hex, alpha) {
            const value = String(hex || '').replace('#', '');
            if (!/^[0-9a-fA-F]{6}$/.test(value)) return `rgba(18, 24, 41, ${alpha})`;
            const r = parseInt(value.slice(0,2),16);
            const g = parseInt(value.slice(2,4),16);
            const b = parseInt(value.slice(4,6),16);
            return `rgba(${r}, ${g}, ${b}, ${alpha})`;
        }

        function applyTheme(theme) {
            if (!theme) theme = BUILTIN_THEMES[0];

            const root = document.documentElement;
            root.style.setProperty('--theme-primary', theme.primary || '#00f2fe');
            root.style.setProperty('--theme-secondary', theme.secondary || '#a855f7');
            root.style.setProperty('--theme-card', hexToRgba(theme.card || '#121829', 0.78));
            root.style.setProperty('--neon-cyan', theme.primary || '#00f2fe');
            root.style.setProperty('--neon-purple', theme.secondary || '#a855f7');
            root.style.setProperty('--bg-card', hexToRgba(theme.card || '#121829', 0.78));

            const body = document.getElementById('app-body');
            if (body) {
                body.style.setProperty('--theme-bg-color', '#070913');
                body.style.backgroundColor = '#070913';
                body.style.backgroundImage = theme.backgroundImage
                    ? `url("${theme.backgroundImage}")`
                    : (theme.backgroundCss || BUILTIN_THEMES[0].backgroundCss);
                body.style.backgroundPosition = 'center';
                body.style.backgroundSize = 'cover';
                body.style.backgroundRepeat = 'no-repeat';
            }

            // Lepaskan media lama sepenuhnya agar video OFF benar-benar ringan.
            releaseActiveBackgroundMedia();

            const logo = document.getElementById('brand-logo');
            if (logo) {
                logo.src = theme.logoData || DEFAULT_LOGO_SRC;
                logo.onerror = function() { this.onerror = null; this.src = 'logo.png'; };
                if (theme.logoAssetKey) getThemeAssetDataUrl(theme.logoAssetKey).then(src => { if (src && getActiveThemeId() === theme.id) logo.src = src; });
            }

            const title = document.getElementById('brand-title');
            const subtitle = document.getElementById('brand-subtitle');
            if (title) title.textContent = theme.brandTitle || 'ANI GAMES READY';
            if (subtitle) subtitle.textContent = theme.brandSubtitle || 'ANYWHERE ANYTIME';

            localStorage.setItem(ACTIVE_THEME_KEY, theme.id);
            renderThemeList();

            // Enhancement media hanya boleh aktif di halaman login. Saat sesi rental berjalan,
            // seluruh background image/video/GIF dilepas agar renderer lebih ringan.
            const sessionActive = !!body?.classList.contains('session-active');
            if (!sessionActive && isThemeMediaEnabled() && theme.backgroundMediaKey && theme.backgroundMediaType) {
                getThemeMedia(theme.backgroundMediaKey).then(file => {
                    if (!file || getActiveThemeId() !== theme.id || document.getElementById('app-body')?.classList.contains('session-active')) return;
                    try {
                        const url = URL.createObjectURL(file);
                        activeBackgroundObjectUrl = url;
                        if (theme.backgroundMediaType === 'video') {
                            const video = document.createElement('video');
                            video.id = 'theme-background-video';
                            video.src = url;
                            video.autoplay = true; video.loop = true; video.muted = true; video.playsInline = true;
                            video.preload = 'metadata';
                            Object.assign(video.style, {position:'fixed',inset:'0',width:'100%',height:'100%',objectFit:'cover',zIndex:'-2',pointerEvents:'none'});
                            body && body.prepend(video);
                            const playPromise = video.play();
                            if (playPromise && playPromise.catch) playPromise.catch(() => {});
                        } else if (theme.backgroundMediaType === 'gif') {
                            const img = document.createElement('img');
                            img.id = 'theme-background-gif'; img.src = url;
                            Object.assign(img.style, {position:'fixed',inset:'0',width:'100%',height:'100%',objectFit:'cover',zIndex:'-2',pointerEvents:'none'});
                            body && body.prepend(img);
                        }
                    } catch (error) {
                        console.error('Media background gagal diterapkan:', error);
                        clearActiveMediaObjectUrl();
                    }
                }).catch(() => {});
            }

            if (window.electronAPI?.setDesktopWallpaper) {
                if (theme.desktopWallpaperData) Promise.resolve(window.electronAPI.setDesktopWallpaper(theme.desktopWallpaperData)).catch(() => {});
                else if (theme.wallpaperAssetKey) getThemeAssetDataUrl(theme.wallpaperAssetKey).then(src => { if (src && getActiveThemeId() === theme.id) window.electronAPI.setDesktopWallpaper(src).catch(() => {}); });
            }
            if (theme.backgroundAssetKey) {
                getThemeAssetDataUrl(theme.backgroundAssetKey).then(src => {
                    if (src && getActiveThemeId() === theme.id && !body?.classList.contains('session-active')) {
                        body.style.backgroundImage = `url("${src}")`;
                    }
                });
            }
        }

        function renderThemeList() {
            const container = document.getElementById('theme-list');
            if (!container) return;

            const activeId = getActiveThemeId();
            container.innerHTML = '';

            themes.forEach(theme => {
                const card = document.createElement('div');
                card.className = `theme-card${theme.id === activeId ? ' active' : ''}`;

                const preview = document.createElement('div');
                preview.className = 'theme-preview';
                preview.style.backgroundImage = theme.backgroundImage
                    ? `url("${theme.backgroundImage}")`
                    : (theme.backgroundCss || 'linear-gradient(135deg,#070913,#1e1033)');

                const name = document.createElement('div');
                name.className = 'theme-card-name';
                name.textContent = `${theme.name}${theme.id === activeId ? ' • AKTIF' : ''}`;

                const actions = document.createElement('div');
                actions.className = 'theme-card-actions';

                const applyBtn = document.createElement('button');
                applyBtn.className = 'btn btn-primary';
                applyBtn.type = 'button';
                applyBtn.textContent = theme.id === activeId ? 'Aktif' : 'Pakai';
                applyBtn.disabled = theme.id === activeId;
                applyBtn.onclick = () => {
                    applyTheme(theme);
                    showCustomModal(`Tema "${theme.name}" berhasil diterapkan.`, 'TEMA AKTIF', false, '🎨');
                };

                actions.appendChild(applyBtn);

                const editBtn = document.createElement('button');
                editBtn.className = 'btn btn-secondary';
                editBtn.type = 'button';
                editBtn.textContent = 'Edit';
                editBtn.onclick = () => editThemeAdmin(theme.id);
                actions.appendChild(editBtn);

                if (!BUILTIN_THEMES.some(b => b.id === theme.id)) {
                    const deleteBtn = document.createElement('button');
                    deleteBtn.className = 'btn btn-danger';
                    deleteBtn.type = 'button';
                    deleteBtn.textContent = 'Hapus';
                    deleteBtn.onclick = () => deleteThemeAdmin(theme.id);
                    actions.appendChild(deleteBtn);
                }

                card.appendChild(preview);
                card.appendChild(name);
                card.appendChild(actions);
                container.appendChild(card);
            });
        }

        function resetThemeForm() {
            editingThemeId = null;
            themeBackgroundData = '';
            themeLogoData = '';
            themeWallpaperData = '';
            themeBackgroundMediaFile = null;
            themeBackgroundMediaCleared = false;
            if (themeBackgroundMediaObjectUrl) { try { URL.revokeObjectURL(themeBackgroundMediaObjectUrl); } catch (e) {} themeBackgroundMediaObjectUrl = ''; }
            document.getElementById('theme-name').value = '';
            document.getElementById('theme-brand-title').value = 'ANI GAMES READY';
            document.getElementById('theme-brand-subtitle').value = 'ANYWHERE ANYTIME';
            document.getElementById('theme-primary').value = '#00f2fe';
            document.getElementById('theme-secondary').value = '#a855f7';
            document.getElementById('theme-card-color').value = '#121829';
            document.getElementById('theme-background').value = '';
            document.getElementById('theme-logo').value = '';
            document.getElementById('theme-wallpaper').value = '';
            document.getElementById('theme-background-status').textContent = 'Gambar dikompres otomatis. Video/GIF disimpan sebagai media terpisah. Maksimal 250 MB, tanpa kompres ulang.';
            const mediaEnabledInput = document.getElementById('theme-media-enabled');
            if (mediaEnabledInput) mediaEnabledInput.checked = isThemeMediaEnabled();
            document.getElementById('theme-wallpaper-status').textContent = 'Saat tema diterapkan, wallpaper Windows ikut berubah.';
        }

        function editThemeAdmin(themeId) {
            const theme = themes.find(item => item.id === themeId);
            if (!theme) return;

            const isBuiltin = BUILTIN_THEMES.some(item => item.id === themeId);
            editingThemeId = isBuiltin ? null : theme.id;
            themeBackgroundData = theme.backgroundImage || '';
            themeLogoData = theme.logoData || '';
            themeWallpaperData = theme.desktopWallpaperData || '';
            themeBackgroundMediaFile = null;
            themeBackgroundMediaCleared = false;
            document.getElementById('theme-name').value = isBuiltin ? `${theme.name} Custom` : (theme.name || '');
            document.getElementById('theme-brand-title').value = theme.brandTitle || 'ANI GAMES READY';
            document.getElementById('theme-brand-subtitle').value = theme.brandSubtitle || 'ANYWHERE ANYTIME';
            document.getElementById('theme-primary').value = theme.primary || '#00f2fe';
            document.getElementById('theme-secondary').value = theme.secondary || '#a855f7';
            document.getElementById('theme-card-color').value = theme.card || '#121829';
            document.getElementById('theme-background').value = '';
            document.getElementById('theme-logo').value = '';
            document.getElementById('theme-wallpaper').value = '';
            document.getElementById('theme-background-status').textContent = theme.backgroundMediaType ? `Media tersimpan: ${theme.backgroundMediaType.toUpperCase()}. Pilih file baru untuk mengganti. Maksimal 250 MB.` : 'Gambar dikompres otomatis. Video/GIF disimpan sebagai media terpisah. Maksimal 250 MB, tanpa kompres ulang.';
            const mediaEnabledInput = document.getElementById('theme-media-enabled');
            if (mediaEnabledInput) mediaEnabledInput.checked = isThemeMediaEnabled();
            document.getElementById('theme-wallpaper-status').textContent = theme.desktopWallpaperData ? 'Wallpaper tersimpan. Pilih file baru untuk mengganti.' : 'Saat tema diterapkan, wallpaper Windows ikut berubah.';
        }

        function compressImageFile(file, maxDimension, quality = 0.82) {
            return new Promise((resolve, reject) => {
                if (!file) return resolve('');
                if (!file.type.startsWith('image/')) return reject(new Error('File harus berupa gambar.'));

                const reader = new FileReader();
                reader.onload = () => {
                    const img = new Image();
                    img.onload = () => {
                        const scale = Math.min(1, maxDimension / Math.max(img.width, img.height));
                        const canvas = document.createElement('canvas');
                        canvas.width = Math.max(1, Math.round(img.width * scale));
                        canvas.height = Math.max(1, Math.round(img.height * scale));
                        const ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                        resolve(canvas.toDataURL('image/webp', quality));
                    };
                    img.onerror = () => reject(new Error('Gagal membaca gambar.'));
                    img.src = reader.result;
                };
                reader.onerror = () => reject(new Error('Gagal membaca file.'));
                reader.readAsDataURL(file);
            });
        }

        async function handleThemeImageChange(input, target) {
            const file = input.files && input.files[0];
            if (!file) return;
            try {
                if (target === 'background' && (file.type === 'video/mp4' || file.type === 'video/mpeg' || file.name.toLowerCase().endsWith('.mpg') || file.name.toLowerCase().endsWith('.mpeg') || file.type === 'image/gif')) {
                    if (file.size > 250 * 1024 * 1024) throw new Error('Video/GIF maksimal 250 MB.');
                    themeBackgroundMediaFile = file;
                    themeBackgroundData = '';
                    themeBackgroundMediaCleared = false;
                    themeBackgroundMediaObjectUrl = URL.createObjectURL(file);
                    document.getElementById('theme-background-status').textContent = `Media dipilih: ${file.name} (${Math.round(file.size/1024/1024*10)/10} MB). Maksimal 250 MB, tanpa kompres ulang. Akan disimpan saat tema disimpan.`;
                    return;
                }
                if (!file.type.startsWith('image/')) throw new Error('Format background tidak didukung. Gunakan PNG/JPG/WEBP/GIF/MP4/MPG.');
                const data = await compressImageFile(file, target === 'background' ? 1920 : 512);
                if (target === 'background') {
                    themeBackgroundData = data;
                    themeBackgroundMediaFile = null;
                    themeBackgroundMediaCleared = true;
                    document.getElementById('theme-background-status').textContent = `Gambar dipilih: ${file.name}`;
                } else {
                    themeLogoData = data;
                }
            } catch (error) {
                input.value = '';
                showCustomModal(error.message || 'Gagal memproses file.', 'FILE TIDAK VALID', true, '⚠️');
            }
        }

        async function handleThemeWallpaperChange(input) {
            const file = input.files && input.files[0];
            if (!file) return;
            try {
                themeWallpaperData = await compressImageFile(file, 2560, 0.88);
                document.getElementById('theme-wallpaper-status').textContent = `Wallpaper dipilih: ${file.name}`;
            } catch (error) {
                input.value = '';
                showCustomModal(error.message || 'Gagal memproses wallpaper.', 'WALLPAPER TIDAK VALID', true, '🖥️');
            }
        }

        async function saveThemeAdmin() {
            const name = document.getElementById('theme-name').value.trim();
            const brandTitle = document.getElementById('theme-brand-title').value.trim() || 'ANI GAMES READY';
            const brandSubtitle = document.getElementById('theme-brand-subtitle').value.trim() || 'ANYWHERE ANYTIME';
            const primary = document.getElementById('theme-primary').value;
            const secondary = document.getElementById('theme-secondary').value;
            const card = document.getElementById('theme-card-color').value;

            if (!name) {
                showCustomModal('Nama tema wajib diisi.', 'FORM TEMA', true, '🎨');
                return;
            }

            const existing = editingThemeId ? themes.find(theme => theme.id === editingThemeId) : null;
            const id = editingThemeId || `custom-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;

            const theme = {
                id,
                name,
                brandTitle,
                brandSubtitle,
                primary,
                secondary,
                card,
                backgroundImage: '',
                backgroundAssetKey: existing?.backgroundAssetKey || '',
                backgroundCss: existing?.backgroundCss || BUILTIN_THEMES[0].backgroundCss,
                logoData: '',
                logoAssetKey: existing?.logoAssetKey || '',
                desktopWallpaperData: '',
                wallpaperAssetKey: existing?.wallpaperAssetKey || '',
                backgroundMediaType: themeBackgroundMediaFile ? (themeBackgroundMediaFile.type === 'image/gif' ? 'gif' : 'video') : (themeBackgroundMediaCleared ? '' : (existing?.backgroundMediaType || '')),
                backgroundMediaKey: themeBackgroundMediaFile ? `theme-media-${id}` : (themeBackgroundMediaCleared ? '' : (existing?.backgroundMediaKey || ''))
            };

            const index = themes.findIndex(item => item.id === id);
            if (index >= 0) themes[index] = theme;
            else themes.push(theme);

            if (themeBackgroundData) {
                theme.backgroundAssetKey = theme.backgroundAssetKey || `theme-asset-bg-${id}`;
                await putThemeAsset(theme.backgroundAssetKey, themeBackgroundData);
            } else if (themeBackgroundMediaCleared && existing?.backgroundAssetKey) {
                await deleteThemeAsset(existing.backgroundAssetKey);
                theme.backgroundAssetKey = '';
            }
            if (themeLogoData) {
                theme.logoAssetKey = theme.logoAssetKey || `theme-asset-logo-${id}`;
                await putThemeAsset(theme.logoAssetKey, themeLogoData);
            }
            if (themeWallpaperData) {
                theme.wallpaperAssetKey = theme.wallpaperAssetKey || `theme-asset-wallpaper-${id}`;
                await putThemeAsset(theme.wallpaperAssetKey, themeWallpaperData);
            }
            saveThemes();
            themes = loadThemes();
            const savedTheme = themes.find(t => t.id === id) || theme;
            applyTheme(savedTheme);
            if (themeBackgroundMediaFile) {
                const mediaFile = themeBackgroundMediaFile;
                const mediaKey = theme.backgroundMediaKey;
                putThemeMedia(mediaKey, mediaFile).then(() => {
                    if (getActiveThemeId() === theme.id) applyTheme(theme);
                });
            } else if (themeBackgroundMediaCleared && existing?.backgroundMediaKey) {
                deleteThemeMedia(existing.backgroundMediaKey);
            }
            resetThemeForm();
            showCustomModal(`Tema "${name}" berhasil disimpan dan diterapkan.`, 'TEMA TERSIMPAN', false, '✅');
        }

        function deleteThemeAdmin(themeId) {
            const theme = themes.find(item => item.id === themeId);
            if (!theme || BUILTIN_THEMES.some(b => b.id === themeId)) return;

            if (!confirm(`Hapus tema "${theme.name}"?`)) return;

            themes = themes.filter(item => item.id !== themeId);
            saveThemes();
            deleteThemeMedia(theme.backgroundMediaKey);
            deleteThemeAsset(theme.backgroundAssetKey);
            deleteThemeAsset(theme.logoAssetKey);
            deleteThemeAsset(theme.wallpaperAssetKey);

            if (getActiveThemeId() === themeId) {
                applyTheme(BUILTIN_THEMES[0]);
            } else {
                renderThemeList();
            }
            resetThemeForm();
        }

        function resetActiveTheme() {
            applyTheme(BUILTIN_THEMES[0]);
            resetThemeForm();
            showCustomModal('Tema dikembalikan ke Default Cyber.', 'RESET TEMA', false, '🔄');
        }

        document.getElementById('theme-background').addEventListener('change', (e) => {
            handleThemeImageChange(e.target, 'background');
        });
        document.getElementById('theme-media-enabled').addEventListener('change', (e) => {
            setThemeMediaEnabled(e.target.checked);
            applyTheme(getActiveTheme());
        });

        document.addEventListener('visibilitychange', () => {
            const video = document.getElementById('theme-background-video');
            if (!video) return;
            if (document.hidden) {
                try { video.pause(); } catch (e) {}
            } else if (isThemeMediaEnabled()) {
                const playPromise = video.play();
                if (playPromise && playPromise.catch) playPromise.catch(() => {});
            }
        });

        document.getElementById('theme-logo').addEventListener('change', (e) => {
            handleThemeImageChange(e.target, 'logo');
        });
        document.getElementById('theme-wallpaper').addEventListener('change', (e) => {
            handleThemeWallpaperChange(e.target);
        });

        function recoverActiveSession() {
            try {
                const raw = localStorage.getItem(ACTIVE_SESSION_KEY);
                if (!raw) return;
                const state = JSON.parse(raw);
                const code = String(state.code || '').toUpperCase();
                const deadline = Number(state.deadlineMs);
                if (!code || !dbUsers[code] || !Number.isFinite(deadline)) {
                    clearPersistedActiveSession();
                    if (dbUsers[TEST_SESSION_CODE]) { delete dbUsers[TEST_SESSION_CODE]; saveDB(); }
                    return;
                }
                const remaining = Math.ceil((deadline - Date.now()) / 1000);
                if (remaining <= 0) {
                    dbUsers[code].remainingSeconds = 0;
                    if (code === TEST_SESSION_CODE) delete dbUsers[code];
                    saveDB();
                    clearPersistedActiveSession();
                    writeSystemLog(`Sesi ${code} ditemukan sudah habis saat recovery.`);
                    return;
                }
                currentActiveCode = code;
                timerDeadlineMs = deadline;
                dbUsers[code].remainingSeconds = remaining;
                timerCompact = false;
                lastSavedRemaining = null;
                document.getElementById('lock-screen').classList.add('hidden');
                enterSessionVisualMode();
                document.getElementById('timer-widget').classList.remove('hidden', 'compact');
                if (window.electronAPI) {
                    window.electronAPI.setLockMode(false);
                    window.electronAPI.resizeTimerWindow?.(500, 76);
                }
                updateTimer();
                if (timerInterval) clearInterval(timerInterval);
                timerInterval = window.setInterval(updateTimer, 1000);
                writeSystemLog(`Sesi ${code} dipulihkan setelah Billing dibuka ulang.`);
            } catch (error) {
                console.error('Recovery sesi gagal:', error);
                writeSystemLog('Recovery sesi gagal: ' + error.message, 'ERROR');
                clearPersistedActiveSession();
            }
        }

        /* --- FUNGSI BILLING CLIENT --- */
        function enterSessionVisualMode() {
            const body = document.getElementById('app-body');
            if (!body) return;

            // Hentikan dan lepaskan video/GIF + object URL segera.
            releaseActiveBackgroundMedia();
            body.classList.add('session-active');
            body.style.backgroundImage = 'none';

            // Pastikan elemen dekorasi login tidak ikut dirender selama sesi.
            document.querySelectorAll('.bg-grid, .bg-glow-1, .bg-glow-2').forEach(el => {
                el.style.display = 'none';
            });
        }

        function restoreLoginVisualMode() {
            const body = document.getElementById('app-body');
            if (!body) return;

            body.classList.remove('session-active');
            document.querySelectorAll('.bg-grid, .bg-glow-1, .bg-glow-2').forEach(el => {
                el.style.display = '';
            });

            // Terapkan kembali tema login, termasuk media background bila diaktifkan.
            const activeTheme = getActiveTheme();
            if (activeTheme) applyTheme(activeTheme);
        }

        function startTenMinuteTest() {
            if (currentActiveCode || localStorage.getItem('billing_remote_paused_code')) {
                return showCustomModal('Selesaikan sesi yang sedang aktif atau dijeda sebelum menjalankan test timer.', 'SESI MASIH AKTIF', true, '⏱️');
            }

            if (dbUsers[TEST_SESSION_CODE]) {
                delete dbUsers[TEST_SESSION_CODE];
            }

            dbUsers[TEST_SESSION_CODE] = {
                category: 'reguler',
                remainingSeconds: 600,
                expiryDate: '',
                hiddenTest: true
            };
            saveDB();
            document.getElementById('user-code-input').value = '';
            currentActiveCode = TEST_SESSION_CODE;
            timerDeadlineMs = Date.now() + 600000;
            persistActiveSession();
            writeSystemLog('FREE TEST 10 menit dimulai dari halaman awal.');
            timerCompact = false;
            lastSavedRemaining = null;

            document.getElementById('lock-screen').classList.add('hidden');
            enterSessionVisualMode();
            const timerWidget = document.getElementById('timer-widget');
            timerWidget.classList.remove('hidden', 'compact');

            const minimizeButton = document.getElementById('timer-minimize');
            if (minimizeButton) {
                minimizeButton.innerText = '−';
                minimizeButton.title = 'Kecilkan timer menjadi popup';
            }
            if (window.electronAPI) {
                window.electronAPI.setLockMode(false);
                window.electronAPI.resizeTimerWindow?.(500, 76);
            }
            requestAnimationFrame(() => syncTimerWindowSize());

            if (timerInterval) clearInterval(timerInterval);
            updateTimer();
            timerInterval = window.setInterval(updateTimer, 1000);
        }

        function startSession() {
            const inputCode = document.getElementById('user-code-input').value.trim().toUpperCase();
            
            if (!inputCode) return showCustomModal("Silahkan masukkan Kode Unik terlebih dahulu!", "KODE KOSONG", true, "⌨️");
            if (currentActiveCode) return showCustomModal('Selesaikan sesi yang sedang aktif terlebih dahulu.', 'SESI MASIH AKTIF', true, '⏱️');
            const pausedCode = String(localStorage.getItem('billing_remote_paused_code') || '').toUpperCase();
            if (pausedCode) {
                if (pausedCode === inputCode && dbUsers[inputCode]) {
                    return resumePausedSession(inputCode);
                }
                return showCustomModal('PC masih memiliki sesi yang dijeda. Lanjutkan sesi tersebut atau Stop dari Admin.', 'SESI DIJEDA', true, '⏸️');
            }

            const user = dbUsers[inputCode];
            if (!user) return showCustomModal("Kode Unik tidak ditemukan!", "AKSES DITOLAK", true, "❌");

            if (user.expiryDate) {
                const now = new Date();
                const exp = new Date(user.expiryDate);
                if (now > exp) return showCustomModal("Masa aktif (Expired Date) paket ini telah habis!", "PAKET EXPIRED", true, "⏳");
            }

            user.remainingSeconds = Math.max(0, Number(user.remainingSeconds) || 0);
            if (user.remainingSeconds <= 0) return showCustomModal("Waktu telah habis silahkan hubungi admin 082298316902", "WAKTU HABIS", true, "⏰");

            currentActiveCode = inputCode;
            timerDeadlineMs = Date.now() + (user.remainingSeconds * 1000);
            persistActiveSession();
            writeSystemLog(`Sesi ${inputCode} dimulai.`);
            timerCompact = false;
            lastSavedRemaining = null;
            
            // Sembunyikan lock screen dan ubah background body transparan agar floating murni di atas desktop.
            document.getElementById('lock-screen').classList.add('hidden');
            enterSessionVisualMode();
            const timerWidget = document.getElementById('timer-widget');
            timerWidget.classList.remove('hidden', 'compact');

            const minimizeButton = document.getElementById('timer-minimize');
            if (minimizeButton) {
                minimizeButton.innerText = '−';
                minimizeButton.title = 'Kecilkan timer menjadi popup';
            }

            // Ukuran awal dibuat cukup besar agar angka timer selalu terbaca.
            if (window.electronAPI && window.electronAPI.resizeTimerWindow) {
                window.electronAPI.resizeTimerWindow(500, 76);
            }
            requestAnimationFrame(() => syncTimerWindowSize());

            if (window.electronAPI) {
                window.electronAPI.setLockMode(false);
                setTimeout(syncTimerWindowSize, 120);
            }

            if (timerInterval) clearInterval(timerInterval);
            updateTimer();
            timerInterval = window.setInterval(updateTimer, 1000);
        }

        // Countdown dihitung dari deadline waktu nyata. setInterval hanya dipakai
        // untuk menyegarkan tampilan; keterlambatan callback tidak menghentikan billing.
        function updateTimer() {
            if (!currentActiveCode || timerDeadlineMs === null) return;
            const user = dbUsers[currentActiveCode];
            if (!user) return;

            const remaining = Math.max(0, Math.ceil((timerDeadlineMs - Date.now()) / 1000));
            user.remainingSeconds = remaining;
            updateTimerDisplay();

            if (remaining <= 0) {
                writeSystemLog(`Sesi ${currentActiveCode} selesai karena waktu habis.`);
                saveDB();
                stopActiveSession();
                return;
            }

            // Simpan berkala tanpa menjadikan jumlah callback sebagai sumber waktu.
            if (lastSavedRemaining === null || (lastSavedRemaining - remaining) >= 30) {
                saveDB();
                persistActiveSession();
                lastSavedRemaining = remaining;
            }
        }

        function updateTimerDisplay() {
            if (!currentActiveCode) return;
            const totalSecs = dbUsers[currentActiveCode].remainingSeconds;
            const hrs = Math.floor(totalSecs / 3600);
            const mins = Math.floor((totalSecs % 3600) / 60);
            const secs = totalSecs % 60;
            
            document.getElementById('timer-display').innerText = `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
            const ctx=document.getElementById('timer-context'); if(ctx) ctx.textContent=`SESI AKTIF • ${currentActiveCode===TEST_SESSION_CODE?'FREE TEST 10 MENIT':'KODE '+currentActiveCode} • ${user?.category||'REGULER'}`;
            window.updateSessionLoginUI?.();
        }

        function pauseActiveSession() {
            if (!currentActiveCode) return false;
            const pausedCode = currentActiveCode;
            if (timerDeadlineMs !== null) {
                const user = dbUsers[pausedCode];
                if (user) user.remainingSeconds = Math.max(0, Math.ceil((timerDeadlineMs - Date.now()) / 1000));
            }
            clearInterval(timerInterval);
            timerInterval = null;
            timerDeadlineMs = null;
            lastSavedRemaining = null;
            clearPersistedActiveSession();
            localStorage.setItem('billing_remote_paused_code', pausedCode);
            saveDB();
            currentActiveCode = null;
            writeSystemLog(`Sesi ${pausedCode} dijeda. Sisa waktu tersimpan.`);
            restoreLoginVisualMode();
            document.getElementById('lock-screen').classList.remove('hidden');
            document.getElementById('timer-widget')?.classList.add('hidden');
            if (window.electronAPI) window.electronAPI.setLockMode(true);
            window.updateSessionLoginUI?.();
            return true;
        }

        function resumePausedSession(code) {
            const c = String(code || localStorage.getItem('billing_remote_paused_code') || '').toUpperCase();
            const user = c && dbUsers[c];
            const remain = user ? Math.max(0, Number(user.remainingSeconds) || 0) : 0;
            if (!c || !user || remain <= 0) return showCustomModal('Sesi yang dijeda sudah tidak memiliki waktu.', 'SESI TIDAK TERSEDIA', true, '⏰');
            localStorage.removeItem('billing_remote_paused_code');
            currentActiveCode = c;
            timerDeadlineMs = Date.now() + remain * 1000;
            persistActiveSession();
            document.getElementById('lock-screen').classList.add('hidden');
            enterSessionVisualMode();
            document.getElementById('timer-widget')?.classList.remove('hidden');
            if (timerInterval) clearInterval(timerInterval);
            updateTimer();
            timerInterval = window.setInterval(updateTimer, 1000);
            saveDB();
            return true;
        }

        function stopActiveSession() {
            const endedCode = currentActiveCode || String(localStorage.getItem('billing_remote_paused_code') || '').toUpperCase();
            if (!endedCode) return false;
            clearInterval(timerInterval);
            timerInterval = null;
            timerDeadlineMs = null;
            lastSavedRemaining = null;
            clearPersistedActiveSession();
            localStorage.removeItem('billing_remote_paused_code');
            if (endedCode === TEST_SESSION_CODE) delete dbUsers[TEST_SESSION_CODE];
            saveDB();
            currentActiveCode = null;
            writeSystemLog(`Sesi ${endedCode} dihentikan.`);
            document.getElementById('timer-display').innerText = '00:00:00';
            document.getElementById('user-code-input').value = '';

            const timerWidget = document.getElementById('timer-widget');
            timerWidget.classList.add('hidden');
            timerWidget.classList.remove('dragging', 'compact');
            timerCompact = false;

            const minimizeButton = document.getElementById('timer-minimize');
            if (minimizeButton) {
                minimizeButton.innerText = '−';
                minimizeButton.title = 'Kecilkan timer menjadi popup';
            }

            // Tutup modal yang mungkin sedang terbuka agar halaman login langsung terlihat.
            document.getElementById('custom-modal').classList.add('hidden');
            document.getElementById('admin-login-modal').classList.add('hidden');
            document.getElementById('admin-panel').classList.add('hidden');

            restoreLoginVisualMode();
            document.getElementById('lock-screen').classList.remove('hidden');
            window.updateSessionLoginUI?.();

            // Kembalikan seluruh window ke mode fullscreen/kiosk untuk halaman login.
            if (window.electronAPI) {
                window.electronAPI.setLockMode(true);
            }

            // Beri Electron waktu menyelesaikan transisi fullscreen/kiosk sebelum fokus input.
            setTimeout(focusLoginInput, 120);
        }

        function closeAdminPanel() {
            document.getElementById('admin-panel').classList.add('hidden');
        }

        async function restartBillingApp(fromAdmin = false, afterRestore = false) {
            if (!window.electronAPI?.restartBilling) return showCustomModal('Fungsi restart billing belum tersedia.', 'ERROR', true, '⚠️');
            if (!afterRestore && !confirm('Restart Billing akan menutup lalu membuka aplikasi kembali. Data tetap disimpan. Lanjutkan?')) return;
            try {
                persistActiveSession();
                saveDB();
                writeSystemLog('Restart Billing diminta' + (fromAdmin ? ' dari Admin.' : '.'));
                await window.electronAPI.restartBilling();
            } catch (error) {
                showCustomModal('Restart Billing gagal: ' + error.message, 'RESTART GAGAL', true, '⚠️');
            }
        }

        async function exitBillingApp() {
            if (!window.electronAPI?.exitBilling) return showCustomModal('Fungsi Exit Billing belum tersedia.', 'ERROR', true, '⚠️');
            if (!confirm('Yakin ingin keluar total dari Billing?')) return;
            try {
                persistActiveSession();
                saveDB();
                writeSystemLog('Exit Billing dari Admin.');
                await window.electronAPI.exitBilling();
            } catch (error) {
                showCustomModal('Exit Billing gagal: ' + error.message, 'EXIT GAGAL', true, '⚠️');
            }
        }

        function requestPowerAction(action) {
            const messages = {
                logoff: 'Yakin ingin Log Off dari Windows?',
                restart: 'Yakin ingin Restart komputer?',
                shutdown: 'Yakin ingin Shutdown komputer?'
            };

            const message = messages[action];
            if (!message) return;

            if (!confirm(message)) return;

            if (!window.electronAPI || !window.electronAPI.powerAction) {
                showCustomModal('Fungsi power Windows belum tersedia.', 'ERROR', true, '⚠️');
                return;
            }

            // Shutdown/restart Windows bukan Stop Rental. Simpan sesi/deadline
            // terlebih dahulu agar saat PC hidup kembali timer dapat recovery.
            persistActiveSession();
            saveDB();
            writeSystemLog(`Aksi Windows: ${String(action)}.`);
            window.electronAPI.powerAction(action);
        }

        function autoSetExpiry() {
            const category = document.getElementById('admin-category').value;
            const expiryInput = document.getElementById('admin-expiry');
            
            if (category === 'mingguan') expiryInput.value = getFutureDate(7);
            else if (category === 'bulanan') expiryInput.value = getFutureDate(30);
            else expiryInput.value = '';
        }

        function saveUserAdmin() {
            const code = document.getElementById('admin-code').value.trim().toUpperCase();
            const category = document.getElementById('admin-category').value;
            const hours = Math.max(0, parseInt(document.getElementById('admin-hours').value, 10) || 0);
            const minutes = Math.max(0, Math.min(59, parseInt(document.getElementById('admin-minutes').value, 10) || 0));
            const addedSeconds = (hours * 3600) + (minutes * 60);
            const expiry = document.getElementById('admin-expiry').value;

            if (!code) return showCustomModal("Kode Unik Wajib Diisi!", "ERROR FORM", true, "⚠️");
            if (addedSeconds <= 0) return showCustomModal("Durasi harus lebih dari 0 menit!", "DURASI TIDAK VALID", true, "⏱️");

            if (!dbUsers[code]) {
                dbUsers[code] = { category: category, remainingSeconds: addedSeconds, expiryDate: expiry };
            } else {
                dbUsers[code].category = category;
                dbUsers[code].remainingSeconds = Math.max(0, Number(dbUsers[code].remainingSeconds) || 0) + addedSeconds;
                if (expiry) dbUsers[code].expiryDate = expiry;
            }

            saveDB();
            renderUserTable();
            try { window.v11SyncRental?.(code); } catch (_) {}

            document.getElementById('admin-code').value = '';
            document.getElementById('admin-hours').value = '';
            document.getElementById('admin-minutes').value = '';
            showCustomModal(`Data User ${code} berhasil disimpan!`, "SUKSES", false, "✅");
        }

        function deleteUser(code) {
            if (confirm(`Apakah Anda yakin ingin menghapus user ${code}?`)) {
                delete dbUsers[code];
                try { window.v11DeleteRental?.(code); } catch (_) {}
            }
            saveDB();
            renderUserTable();
        }

        function renderUserTable() {
            const tbody = document.getElementById('user-table-body');
            tbody.innerHTML = '';

            for (let code in dbUsers) {
                const u = dbUsers[code];
                if (u && u.hiddenTest) continue;
                const hrs = Math.floor(u.remainingSeconds / 3600);
                const mins = Math.floor((u.remainingSeconds % 3600) / 60);

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td><strong style="color: var(--neon-cyan); font-family: 'Orbitron';">${code}</strong></td>
                    <td><span class="badge badge-${u.category || 'reguler'}">${u.category || 'reguler'}</span></td>
                    <td>${hrs} Jam ${mins} Menit</td>
                    <td>${u.expiryDate ? new Date(u.expiryDate).toLocaleString('id-ID') : 'Tanpa Batas'}</td>
                    <td>
                        <button class="btn btn-danger" style="padding: 6px 12px; font-size: 11px;" onclick="deleteUser('${code}')">Hapus</button>
                    </td>
                `;
                tbody.appendChild(tr);
            }
        }

        // Inisialisasi modul tema V10 tanpa mengubah alur billing V9.
        migrateLegacyThemeAssets();
        applyTheme(getActiveTheme());

        // Daftar tema dirender saat Admin dibuka agar DOM awal lebih ringan.
        // Aktifkan drag timer setelah semua elemen DOM tersedia.
        initTimerDragging();
        saveDB();
        setTimeout(focusLoginInput, 150);
        // Recovery dijalankan setelah seluruh fungsi V10 tersedia.
        window.addEventListener('load', () => {
            const versionNode = document.getElementById('app-version-code');
            if (versionNode) versionNode.textContent = APP_VERSION;
            writeSystemLog(`Billing ${APP_VERSION} loaded.`);
            recoverActiveSession();
            scheduleAutoBackup();
            startAutoBackupWatcher();
        });
    