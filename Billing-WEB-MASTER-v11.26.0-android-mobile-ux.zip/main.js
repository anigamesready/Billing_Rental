const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { execFile } = require('child_process');

let mainWindow;
const approvedBackupRoots = new Set();

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1280,
        height: 720,
        fullscreen: true,
        kiosk: true,
        alwaysOnTop: true,
        frame: false,
        transparent: true,
        resizable: false,
        minimizable: false,
        backgroundColor: '#00000000',
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true
        }
    });

    mainWindow.loadFile('billing.html');
    mainWindow.setAlwaysOnTop(true, 'screen-saver');

    mainWindow.webContents.on('did-finish-load', () => {
        if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.setFocusable(true);
            mainWindow.focus();
        }
    });
}

// IPC Handler untuk Kunci / Buka Layar Billing
ipcMain.on('set-lock-mode', (event, isLocked) => {
    try {
        const shouldLock = Boolean(isLocked);

        if (mainWindow) {
            mainWindow.setKiosk(shouldLock);
            mainWindow.setFullScreen(shouldLock);
            mainWindow.setAlwaysOnTop(shouldLock, 'screen-saver');

            if (shouldLock) {
                // Kembali ke layar login fullscreen/kiosk.
                mainWindow.setIgnoreMouseEvents(false);
                mainWindow.setFocusable(true);
                mainWindow.focus();
            } else {
                // Saat sesi aktif, jendela dibuat sekecil timer dan tetap di atas desktop.
                mainWindow.setIgnoreMouseEvents(false);
                mainWindow.setAlwaysOnTop(true, 'floating');
                mainWindow.setResizable(false);
                if (mainWindow.isMinimized()) mainWindow.restore();
                mainWindow.setSize(500, 76, true);
                mainWindow.center();
            }
        }
    } catch (err) {
        console.error("Gagal mengubah mode lock:", err);
    }
});

ipcMain.on('resize-timer-window', (event, width, height) => {
    if (!mainWindow || mainWindow.isDestroyed()) return;

    const safeWidth = Math.max(220, Math.ceil(Number(width) || 0));
    const safeHeight = Math.max(60, Math.ceil(Number(height) || 0));

    try {
        mainWindow.setContentSize(safeWidth, safeHeight, true);
        mainWindow.center();
    } catch (err) {
        console.error("Gagal mengubah ukuran jendela timer:", err);
    }
});

ipcMain.on('minimize-timer-window', () => {
    // Tombol '-' di UI sekarang hanya mengubah timer menjadi popup compact.
    // Tidak lagi meminimalkan jendela Electron ke taskbar.
    if (!mainWindow || mainWindow.isDestroyed()) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
});

ipcMain.on('restore-timer-window', () => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
});

// Pengaturan wallpaper desktop Windows. Renderer hanya mengirim data gambar;
// file ditulis ke folder userData dan Windows diberi tahu untuk menerapkannya.
ipcMain.handle('set-desktop-wallpaper', async (event, dataUrl) => {
    if (event.sender !== mainWindow?.webContents) return false;
    if (process.platform !== 'win32') return false;
    const value = String(dataUrl || '');
    const match = value.match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/i);
    if (!match) return false;

    try {
        const ext = match[1].toLowerCase() === 'jpeg' ? 'jpg' : match[1].toLowerCase();
        const wallpaperPath = path.join(app.getPath('userData'), `ani-games-wallpaper.${ext}`);
        fs.writeFileSync(wallpaperPath, Buffer.from(match[2], 'base64'));

        await new Promise((resolve, reject) => {
            execFile('reg.exe', ['add', 'HKCU\\Control Panel\\Desktop', '/v', 'Wallpaper', '/t', 'REG_SZ', '/d', wallpaperPath, '/f'], (error) => {
                if (error) reject(error); else resolve();
            });
        });
        await new Promise((resolve, reject) => {
            execFile('RUNDLL32.EXE', ['user32.dll,UpdatePerUserSystemParameters'], (error) => {
                if (error) reject(error); else resolve();
            });
        });
        return true;
    } catch (err) {
        console.error('Gagal menerapkan wallpaper desktop:', err);
        return false;
    }
});

// Restart aplikasi Billing tanpa menghapus data. Renderer menyimpan sesi lebih dulu.
ipcMain.handle('restart-billing', (event) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        app.relaunch();
        setTimeout(() => app.exit(0), 100);
        return { ok: true };
    } catch (error) {
        console.error('Gagal restart Billing:', error);
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('exit-billing', (event) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        setTimeout(() => app.quit(), 0);
        return { ok: true };
    } catch (error) {
        console.error('Gagal exit Billing:', error);
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('write-backup', async (event, payload) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        if (!payload || payload.format !== 'ani-games-billing-v10-backup') throw new Error('Format backup tidak valid.');
        const backupDir = path.join(app.getPath('userData'), 'backups');
        fs.mkdirSync(backupDir, { recursive: true });
        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupPath = path.join(backupDir, `billing-v10-${stamp}.json`);
        fs.writeFileSync(backupPath, JSON.stringify(payload, null, 2), 'utf8');
        const files = fs.readdirSync(backupDir)
            .filter(name => name.endsWith('.json'))
            .sort()
            .reverse();
        for (const oldName of files.slice(10)) {
            try { fs.unlinkSync(path.join(backupDir, oldName)); } catch (_) {}
        }
        return { ok: true, path: backupPath };
    } catch (error) {
        console.error('Gagal membuat backup:', error);
        return { ok: false, message: error.message };
    }
});


ipcMain.handle('start-full-backup', async (event, payload) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        if (!payload || payload.format !== 'ani-games-billing-v10-full-backup' || !payload.config) throw new Error('Format backup lengkap tidak valid.');
        const root = path.join(app.getPath('userData'), 'backups', 'full');
        fs.mkdirSync(root, { recursive: true });
        const stamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupDir = path.join(root, `billing-v10-full-${stamp}`);
        fs.mkdirSync(path.join(backupDir, 'media'), { recursive: true });
        fs.writeFileSync(path.join(backupDir, 'config.json'), JSON.stringify(payload.config, null, 2), 'utf8');
        fs.writeFileSync(path.join(backupDir, 'manifest.json'), JSON.stringify({ format: 'ani-games-billing-v10-full-backup', version: 2, createdAt: new Date().toISOString(), media: [] }, null, 2), 'utf8');
        return { ok: true, path: backupDir };
    } catch (error) {
        console.error('Gagal memulai backup lengkap:', error);
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('write-full-backup-media', async (event, payload) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        const root = path.resolve(String(payload?.root || ''));
        const userData = path.resolve(app.getPath('userData'));
        if (!root.startsWith(userData + path.sep)) throw new Error('Lokasi backup tidak diizinkan.');
        const item = payload?.item;
        if (!item?.key || !item?.data) throw new Error('Data media backup tidak valid.');
        const mediaDir = path.join(root, 'media');
        fs.mkdirSync(mediaDir, { recursive: true });
        const safeName = `${String(payload.index ?? 0).padStart(3, '0')}-${String(item.key).replace(/[^a-zA-Z0-9._-]/g, '_')}.bin`;
        const filePath = path.join(mediaDir, safeName);
        fs.writeFileSync(filePath, Buffer.from(item.data));
        return { ok: true, file: `media/${safeName}` };
    } catch (error) {
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('finish-full-backup', async (event, payload) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        const root = path.resolve(String(payload?.root || ''));
        const userData = path.resolve(app.getPath('userData'));
        if (!root.startsWith(userData + path.sep)) throw new Error('Lokasi backup tidak diizinkan.');
        const manifest = { format: 'ani-games-billing-v10-full-backup', version: 2, createdAt: new Date().toISOString(), media: Array.isArray(payload.media) ? payload.media : [] };
        fs.writeFileSync(path.join(root, 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
        return { ok: true, path: root, mediaCount: manifest.media.length };
    } catch (error) {
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('restore-full-backup', async (event) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        const result = await dialog.showOpenDialog(mainWindow, { title: 'Pilih Folder Backup Lengkap Billing V10', properties: ['openDirectory'] });
        if (result.canceled || !result.filePaths?.[0]) return { ok: false, cancelled: true };
        const root = result.filePaths[0];
        const manifestPath = path.join(root, 'manifest.json');
        const configPath = path.join(root, 'config.json');
        if (!fs.existsSync(manifestPath) || !fs.existsSync(configPath)) throw new Error('Folder bukan backup lengkap V10 yang valid.');
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (manifest.format !== 'ani-games-billing-v10-full-backup') throw new Error('Format backup lengkap tidak dikenali.');
        approvedBackupRoots.add(root);
        return { ok: true, root, manifest, config };
    } catch (error) {
        console.error('Gagal membaca backup lengkap:', error);
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('read-backup-file', async (event, filePath) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        const value = String(filePath || '');
        const userData = path.resolve(app.getPath('userData'));
        const resolved = path.resolve(value);
        const approved = Array.from(approvedBackupRoots).some(root => resolved.startsWith(path.resolve(root) + path.sep));
        if (!resolved.startsWith(userData + path.sep) && !approved) throw new Error('Lokasi file backup tidak diizinkan.');
        const stat = fs.statSync(resolved);
        if (!stat.isFile()) throw new Error('File backup tidak ditemukan.');
        if (stat.size > 300 * 1024 * 1024) throw new Error('File media backup terlalu besar.');
        return { ok: true, data: fs.readFileSync(resolved) };
    } catch (error) {
        return { ok: false, message: error.message };
    }
});

ipcMain.handle('restore-backup', async (event) => {
    if (event.sender !== mainWindow?.webContents) return { ok: false, message: 'Pemanggil tidak valid.' };
    try {
        const result = await dialog.showOpenDialog(mainWindow, {
            title: 'Pilih Backup Billing V10',
            properties: ['openFile'],
            filters: [{ name: 'Backup Billing V10', extensions: ['json'] }]
        });
        if (result.canceled || !result.filePaths?.[0]) return { ok: false, cancelled: true };
        const data = JSON.parse(fs.readFileSync(result.filePaths[0], 'utf8'));
        return { ok: true, data };
    } catch (error) {
        console.error('Gagal restore backup:', error);
        return { ok: false, message: error.message };
    }
});

// Kontrol power Windows. Hanya menerima aksi yang sudah di-whitelist.
ipcMain.on('power-action', (event, action) => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    if (event.sender !== mainWindow.webContents) return;

    const powerCommands = {
        logoff: ['/l'],
        restart: ['/r', '/t', '0'],
        shutdown: ['/s', '/t', '0']
    };

    const args = powerCommands[String(action)];
    if (!args) {
        console.error('Aksi power tidak dikenal:', action);
        return;
    }

    const { execFile } = require('child_process');
    execFile('shutdown.exe', args, (error) => {
        if (error) {
            console.error(`Gagal menjalankan ${String(action)}:`, error);
        }
    });
});

app.whenReady().then(() => {
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
});

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});