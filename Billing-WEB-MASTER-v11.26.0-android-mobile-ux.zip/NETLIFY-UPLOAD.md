# Ani Games Billing V11 — Netlify Upload

Paket ini sudah dirapikan untuk deploy manual ke Netlify.

## Upload
1. Extract ZIP ini.
2. Upload isi folder hasil extract sebagai folder deploy Netlify (jangan upload ZIP sebagai file di dalam site).
3. Pastikan environment variables Netlify:
   - `SUPABASE_URL`
   - `SUPABASE_PUBLISHABLE_KEY`
4. Endpoint API produksi: `https://billinganigames.netlify.app/api/v1/*`. Health: `/api/v1/health`.
5. Web Admin tersedia di `/admin.html`.

## Catatan
- Billing PC tetap offline-first/local.
- API V11 sudah menangani CORS dan OPTIONS/preflight untuk client PC.
- Tidak ada Supabase service-role key di frontend.
- Folder `supabase/migrations/` pada source awal kosong, jadi schema/RPC Supabase harus sudah terpasang pada project Supabase yang digunakan.

## Pairing production
- PC dan Android harus memakai `https://billinganigames.netlify.app/api/v1`.
- Netlify Function menerima `SUPABASE_PUBLISHABLE_KEY` (utama) atau `SUPABASE_ANON_KEY` (kompatibilitas).
- Health akan mengembalikan HTTP 503 jika konfigurasi Supabase belum terpasang, sehingga masalah tidak lagi tersamarkan sebagai kegagalan pairing.
