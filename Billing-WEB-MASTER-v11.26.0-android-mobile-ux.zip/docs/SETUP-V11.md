# Ani Games Billing V11 Cloud — P04 Baseline

## Komponen
- PC Billing: Electron, baseline V10.0.0-FINAL-LOCAL-P04.
- Cloud API: Netlify Functions `/api/v1/*`.
- Database/Auth: Supabase PostgreSQL + Auth.
- Web Admin: `/admin.html`.
- Android Admin source: `android/`.

## Alur pairing PC
1. Web Admin: buat akun / login.
2. Akun pertama: **Aktifkan Owner**.
3. Buat reseller bila diperlukan.
4. Buat **Kode Pairing** pada organisasi yang dipilih.
5. PC Billing → Panel Admin → **Cloud V11** → masukkan kode.
6. PC menyimpan token secara lokal.
7. PC heartbeat tiap 20 detik dan mengirim antrean event tiap tersedia internet.

## Offline-first
Timer dan database billing lokal tidak bergantung pada koneksi internet. Event cloud disimpan di outbox lokal dan dikirim ulang ketika online. Perintah dari Web Admin/Android masuk antrean cloud dan diambil PC melalui heartbeat.

## Remote commands
- restart_billing
- logout
- pause / stop
- shutdown
- add_time
- set_theme
- refresh

## Laporan
Cloud menyimpan usage events dengan klasifikasi: usage, transaction, configuration, audit, telemetry, system. Web Admin menampilkan sesi, transaksi, durasi terpakai, free test, dan jumlah PC.

## Security
- Semua tabel utama memakai RLS.
- Security advisor Supabase terakhir: **0 lints**.
- Device token disimpan sebagai hash di database; token asli hanya diberikan saat pairing.
- Publishable key boleh berada di frontend; secret/service-role tidak dimasukkan ke aplikasi.

## Deploy
Source paket sudah siap untuk Netlify. Deploy aktif yang sudah diverifikasi sebelumnya tetap melayani `/api/health`; perubahan V11 lengkap pada paket ini perlu dipublish sebagai deploy baru ke project `billingrental`.

## V11.4.2
Web Admin now requires a selected target PC for rental creation and remote control. PC Billing keeps the login screen visible while an active session runs in a floating timer overlay; active sessions recover after refresh/restart from the persisted deadline.
