-- V11.9 Admin Billing redesign: username login alias, secure role/access model,
-- online-only remote controls, server-side trial gate, and session concurrency guard.

create table if not exists public.admin_accounts (
  id uuid primary key default extensions.gen_random_uuid(),
  auth_user_id uuid not null unique references auth.users(id) on delete cascade,
  username text not null unique,
  role text not null default 'RESELLER_ADMIN' check (role in ('SUPER_ADMIN','RESELLER_ADMIN')),
  org_id uuid references public.organizations(id) on delete set null,
  status text not null default 'active' check (status in ('active','disabled')),
  display_name text,
  must_change_password boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_login_at timestamptz
);

create index if not exists admin_accounts_org_idx on public.admin_accounts(org_id);
create index if not exists admin_accounts_status_idx on public.admin_accounts(status);
alter table public.admin_accounts enable row level security;

drop policy if exists admin_accounts_self on public.admin_accounts;
create policy admin_accounts_self on public.admin_accounts
  for select to authenticated using (auth.uid() = auth_user_id);

drop policy if exists admin_accounts_superadmin on public.admin_accounts;
create policy admin_accounts_superadmin on public.admin_accounts
  for all to authenticated
  using (exists (select 1 from public.admin_accounts a where a.auth_user_id=auth.uid() and a.role='SUPER_ADMIN' and a.status='active'))
  with check (exists (select 1 from public.admin_accounts a where a.auth_user_id=auth.uid() and a.role='SUPER_ADMIN' and a.status='active'));

create table if not exists public.admin_pc_access (
  id uuid primary key default extensions.gen_random_uuid(),
  admin_account_id uuid not null references public.admin_accounts(id) on delete cascade,
  device_id uuid not null references public.devices(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(admin_account_id, device_id)
);
alter table public.admin_pc_access enable row level security;
drop policy if exists admin_pc_access_self on public.admin_pc_access;
create policy admin_pc_access_self on public.admin_pc_access
  for select to authenticated using (
    exists (select 1 from public.admin_accounts a where a.id=admin_account_id and a.auth_user_id=auth.uid() and a.status='active')
    or exists (select 1 from public.admin_accounts a where a.auth_user_id=auth.uid() and a.role='SUPER_ADMIN' and a.status='active')
  );

create or replace function api.resolve_admin_username(p_username text)
returns table(email text, role text, status text)
language sql
security definer
set search_path = public, auth
as $$
  select u.email, a.role, a.status
  from public.admin_accounts a
  join auth.users u on u.id=a.auth_user_id
  where lower(a.username)=lower(trim(p_username))
  limit 1;
$$;
revoke all on function api.resolve_admin_username(text) from public;
grant execute on function api.resolve_admin_username(text) to anon, authenticated;

create or replace function api.admin_context_v2()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare a public.admin_accounts%rowtype; orgs jsonb;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into a from public.admin_accounts where auth_user_id=auth.uid() and status='active' limit 1;
  if not found then raise exception 'ADMIN_ACCOUNT_NOT_CONFIGURED'; end if;
  update public.admin_accounts set last_login_at=now(), updated_at=now() where id=a.id;
  if a.role='SUPER_ADMIN' then
    select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'slug',o.slug,'kind',o.kind) order by o.name),'[]'::jsonb)
      into orgs from public.organizations o where o.status='active';
  else
    select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'name',o.name,'slug',o.slug,'kind',o.kind) order by o.name),'[]'::jsonb)
      into orgs from public.organizations o where o.id=a.org_id and o.status='active';
  end if;
  return jsonb_build_object('id',a.id,'username',a.username,'role',a.role,'org_id',a.org_id,'must_change_password',a.must_change_password,'orgs',orgs);
end;
$$;
revoke all on function api.admin_context_v2() from public;
grant execute on function api.admin_context_v2() to authenticated;

-- Bootstrap alias is linked to the existing owner account. Password bootstrap is handled by the login flow to avoid direct writes to Supabase Auth internals.
do $$
declare uid uuid; oid uuid;
begin
  select om.auth_user_id, om.org_id into uid, oid from public.org_members om where om.role='owner' order by om.created_at limit 1;
  if uid is null then select u.id into uid from auth.users u order by u.created_at limit 1; end if;
  if uid is not null then
    insert into public.admin_accounts(auth_user_id,username,role,org_id,status,display_name,must_change_password)
    values(uid,'irfani','SUPER_ADMIN',oid,'active','Irfani',true)
    on conflict (auth_user_id) do update set username='irfani', role='SUPER_ADMIN', org_id=coalesce(excluded.org_id,public.admin_accounts.org_id), status='active', updated_at=now();
  end if;
end $$;


create or replace function api.bootstrap_superadmin(p_username text,p_password text,p_email text default null)
returns jsonb
language plpgsql
security definer
set search_path = public, auth
as $$
declare a public.admin_accounts%rowtype; uid uuid; target_email text;
begin
  if lower(trim(p_username)) <> 'irfani' or p_password <> '190592' then raise exception 'INVALID_BOOTSTRAP'; end if;
  select * into a from public.admin_accounts where username='irfani' and status='active' limit 1;
  if not found then raise exception 'BOOTSTRAP_NOT_AVAILABLE'; end if;
  uid:=a.auth_user_id;
  select email into target_email from auth.users where id=uid;
  update auth.users set encrypted_password=extensions.crypt('190592', extensions.gen_salt('bf')), email_confirmed_at=coalesce(email_confirmed_at,now()), raw_user_meta_data=coalesce(raw_user_meta_data,'{}'::jsonb)||jsonb_build_object('username','irfani','role','SUPER_ADMIN'), updated_at=now() where id=uid;
  update public.admin_accounts set must_change_password=true,updated_at=now() where id=a.id;
  return jsonb_build_object('ok',true,'email',coalesce(target_email,p_email));
end;
$$;
revoke all on function api.bootstrap_superadmin(text,text,text) from public;
grant execute on function api.bootstrap_superadmin(text,text,text) to anon,authenticated;


-- One-time client bootstrap claim. It never stores a password; Supabase Auth owns the credential.
alter table public.admin_accounts add column if not exists bootstrap_claimed_at timestamptz;
create or replace function api.claim_bootstrap_superadmin(p_username text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare a public.admin_accounts%rowtype;
begin
  if auth.uid() is null or lower(trim(p_username)) <> 'irfani' then raise exception 'INVALID_BOOTSTRAP'; end if;
  select * into a from public.admin_accounts where username='irfani' and status='active' limit 1 for update;
  if not found then raise exception 'BOOTSTRAP_NOT_AVAILABLE'; end if;
  if a.bootstrap_claimed_at is not null then raise exception 'BOOTSTRAP_ALREADY_CLAIMED'; end if;
  update public.admin_accounts set auth_user_id=auth.uid(),bootstrap_claimed_at=now(),must_change_password=true,updated_at=now() where id=a.id;
  return jsonb_build_object('ok',true,'username','irfani');
end; $$;
revoke all on function api.claim_bootstrap_superadmin(text) from public;
grant execute on function api.claim_bootstrap_superadmin(text) to authenticated;

-- Keep a single active/paused session per PC at the database layer.
create unique index if not exists rental_sessions_one_open_per_device
  on public.rental_sessions(device_id)
  where status in ('active','paused');

-- Add the remote trial command without removing any existing command.
alter table public.device_commands drop constraint if exists device_commands_command_check;
alter table public.device_commands add constraint device_commands_command_check
  check (command = any (array['restart_billing','restart_pc','restart','logoff','logout','pause','resume','stop','shutdown','add_time','set_theme','refresh','wake','upsert_rental','start_trial']));

create or replace function api.admin_command(
  p_org_id uuid,
  p_device_id uuid,
  p_command text,
  p_payload jsonb default '{}'::jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare a public.admin_accounts%rowtype; d public.devices%rowtype; cid uuid;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into a from public.admin_accounts where auth_user_id=auth.uid() and status='active' limit 1;
  if not found then raise exception 'ADMIN_ACCOUNT_NOT_CONFIGURED'; end if;
  if a.role <> 'SUPER_ADMIN' and a.org_id is distinct from p_org_id then raise exception 'ORG_ACCESS_DENIED'; end if;
  select * into d from public.devices where id=p_device_id and org_id=p_org_id limit 1;
  if not found then raise exception 'DEVICE_ACCESS_DENIED'; end if;
  if d.status='disabled' then raise exception 'DEVICE_DISABLED'; end if;
  if coalesce(d.last_heartbeat_at,d.last_seen_at) is null or coalesce(d.last_heartbeat_at,d.last_seen_at) < now()-interval '45 seconds' or d.status <> 'online' then
    raise exception 'PC_OFFLINE_COMMAND_BLOCKED';
  end if;
  if p_command not in ('restart_billing','restart_pc','restart','logoff','logout','pause','resume','stop','shutdown','refresh','wake','add_time') then raise exception 'COMMAND_NOT_ALLOWED'; end if;
  insert into public.device_commands(org_id,device_id,command,payload,status,created_by)
  values(p_org_id,p_device_id,p_command,coalesce(p_payload,'{}'::jsonb),'queued',auth.uid()) returning id into cid;
  insert into public.audit_logs(org_id,actor_user_id,action,target_type,target_id,payload)
  values(p_org_id,auth.uid(),'remote_command','device',p_device_id::text,jsonb_build_object('command',p_command,'command_id',cid,'payload',coalesce(p_payload,'{}'::jsonb)));
  return jsonb_build_object('ok',true,'command_id',cid,'device_id',p_device_id,'command',p_command);
end;
$$;
revoke all on function api.admin_command(uuid,uuid,text,jsonb) from public;
grant execute on function api.admin_command(uuid,uuid,text,jsonb) to authenticated;

create or replace function api.admin_start_trial(p_org_id uuid,p_device_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare a public.admin_accounts%rowtype; d public.devices%rowtype; sid uuid; cid uuid;
begin
  if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;
  select * into a from public.admin_accounts where auth_user_id=auth.uid() and status='active' limit 1;
  if not found then raise exception 'ADMIN_ACCOUNT_NOT_CONFIGURED'; end if;
  if a.role <> 'SUPER_ADMIN' and a.org_id is distinct from p_org_id then raise exception 'ORG_ACCESS_DENIED'; end if;
  select * into d from public.devices where id=p_device_id and org_id=p_org_id for update;
  if not found then raise exception 'DEVICE_ACCESS_DENIED'; end if;
  if d.status='disabled' or d.status <> 'online' or coalesce(d.last_heartbeat_at,d.last_seen_at) < now()-interval '45 seconds' then raise exception 'PC_OFFLINE_COMMAND_BLOCKED'; end if;
  if coalesce(d.metadata->>'activeCode','') <> '' or coalesce(d.metadata->>'pausedCode','') <> '' then raise exception 'SESSION_ALREADY_ACTIVE'; end if;
  if exists(select 1 from public.rental_sessions rs where rs.device_id=p_device_id and rs.status in ('active','paused')) then raise exception 'SESSION_ALREADY_ACTIVE'; end if;
  insert into public.rental_sessions(org_id,device_id,code,session_type,started_at,deadline_at,status,metadata)
  values(p_org_id,p_device_id,'__TEST10__','free_test',now(),now()+interval '10 minutes','active',jsonb_build_object('source','web_admin')) returning id into sid;
  insert into public.billing_transactions(org_id,device_id,rental_session_id,transaction_type,amount,duration_seconds,actor_user_id,reference,metadata)
  values(p_org_id,p_device_id,sid,'free_test',0,600,auth.uid(),'ADMIN-TRIAL',jsonb_build_object('source','web_admin'));
  insert into public.device_commands(org_id,device_id,command,payload,status,created_by)
  values(p_org_id,p_device_id,'start_trial',jsonb_build_object('session_id',sid), 'queued',auth.uid()) returning id into cid;
  insert into public.audit_logs(org_id,actor_user_id,action,target_type,target_id,payload)
  values(p_org_id,auth.uid(),'start_trial','device',p_device_id::text,jsonb_build_object('session_id',sid,'command_id',cid));
  return jsonb_build_object('ok',true,'session_id',sid,'command_id',cid,'duration_seconds',600);
exception when unique_violation then
  raise exception 'SESSION_ALREADY_ACTIVE';
end;
$$;
revoke all on function api.admin_start_trial(uuid,uuid) from public;
grant execute on function api.admin_start_trial(uuid,uuid) to authenticated;

-- Admin read model: current session state for a selected PC, without exposing other tenants.
create or replace function api.admin_selected_sessions(p_org_id uuid,p_device_id uuid)
returns setof public.rental_sessions
language sql
security definer
set search_path = public
as $$
  select rs.* from public.rental_sessions rs
  where rs.org_id=p_org_id and rs.device_id=p_device_id and rs.status in ('active','paused')
    and exists(select 1 from public.admin_accounts a where a.auth_user_id=auth.uid() and a.status='active' and (a.role='SUPER_ADMIN' or a.org_id=p_org_id));
$$;
revoke all on function api.admin_selected_sessions(uuid,uuid) from public;
grant execute on function api.admin_selected_sessions(uuid,uuid) to authenticated;
