create or replace function api.billing_command_status(
  p_session_token text,
  p_command_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path to 'public','pg_catalog'
as $function$
declare
  a public.billing_control_accounts%rowtype;
  c public.device_commands%rowtype;
begin
  a:=private.billing_account_by_token(p_session_token);
  select * into c from public.device_commands
  where id=p_command_id and org_id=a.org_id limit 1;
  if not found then raise exception 'COMMAND_NOT_FOUND'; end if;
  return jsonb_build_object(
    'ok',true,'command_id',c.id,'device_id',c.device_id,'command',c.command,
    'status',c.status,'result',coalesce(c.result,'{}'::jsonb),
    'created_at',c.created_at,'acknowledged_at',c.acknowledged_at,
    'delivered_at',c.delivered_at,'completed_at',c.completed_at,
    'delivery_attempts',coalesce(c.delivery_attempts,0)
  );
end
$function$;

grant execute on function api.billing_command_status(text,uuid) to anon, authenticated;
