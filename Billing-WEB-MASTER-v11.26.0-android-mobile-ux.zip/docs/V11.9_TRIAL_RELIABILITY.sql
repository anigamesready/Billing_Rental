create table if not exists public.device_trial_requests (
 id uuid primary key default extensions.gen_random_uuid(),
 org_id uuid not null references public.organizations(id) on delete cascade,
 device_id uuid not null references public.devices(id) on delete cascade,
 created_by uuid references auth.users(id),
 status text not null default 'queued' check (status in ('queued','started','failed','cancelled','expired')),
 command_id uuid references public.device_commands(id) on delete set null,
 session_id uuid references public.rental_sessions(id) on delete set null,
 created_at timestamptz not null default now(),
 started_at timestamptz,
 finished_at timestamptz,
 result jsonb not null default '{}'::jsonb
);
create unique index if not exists device_trial_requests_one_open on public.device_trial_requests(device_id) where status in ('queued','started');
alter table public.device_trial_requests enable row level security;
drop policy if exists device_trial_requests_self on public.device_trial_requests;
create policy device_trial_requests_self on public.device_trial_requests for select to authenticated using (exists(select 1 from public.admin_accounts a where a.auth_user_id=auth.uid() and a.status='active' and (a.role='SUPER_ADMIN' or a.org_id=org_id)));

create or replace function api.admin_start_trial(p_org_id uuid,p_device_id uuid) returns jsonb language plpgsql security definer set search_path=public as $$
declare a public.admin_accounts%rowtype; d public.devices%rowtype; rid uuid; cid uuid;
begin
 if auth.uid() is null then raise exception 'UNAUTHENTICATED'; end if;
 select * into a from public.admin_accounts where auth_user_id=auth.uid() and status='active' limit 1; if not found then raise exception 'ADMIN_ACCOUNT_NOT_CONFIGURED'; end if;
 if a.role<>'SUPER_ADMIN' and a.org_id is distinct from p_org_id then raise exception 'ORG_ACCESS_DENIED'; end if;
 select * into d from public.devices where id=p_device_id and org_id=p_org_id for update; if not found then raise exception 'DEVICE_ACCESS_DENIED'; end if;
 if d.status<>'online' or coalesce(d.last_heartbeat_at,d.last_seen_at)<now()-interval '45 seconds' then raise exception 'PC_OFFLINE_COMMAND_BLOCKED'; end if;
 if coalesce(d.metadata->>'activeCode','')<>'' or coalesce(d.metadata->>'pausedCode','')<>'' then raise exception 'SESSION_ALREADY_ACTIVE'; end if;
 if exists(select 1 from public.rental_sessions rs where rs.device_id=p_device_id and rs.status in ('active','paused')) then raise exception 'SESSION_ALREADY_ACTIVE'; end if;
 insert into public.device_trial_requests(org_id,device_id,created_by) values(p_org_id,p_device_id,auth.uid()) returning id into rid;
 insert into public.device_commands(org_id,device_id,command,payload,status,created_by) values(p_org_id,p_device_id,'start_trial',jsonb_build_object('trial_request_id',rid),'queued',auth.uid()) returning id into cid;
 update public.device_trial_requests set command_id=cid where id=rid;
 insert into public.audit_logs(org_id,actor_user_id,action,target_type,target_id,payload) values(p_org_id,auth.uid(),'start_trial_requested','device',p_device_id::text,jsonb_build_object('trial_request_id',rid,'command_id',cid));
 return jsonb_build_object('ok',true,'trial_request_id',rid,'command_id',cid,'duration_seconds',600);
exception when unique_violation then raise exception 'SESSION_ALREADY_ACTIVE';
end; $$;
revoke all on function api.admin_start_trial(uuid,uuid) from public; grant execute on function api.admin_start_trial(uuid,uuid) to authenticated;

create or replace function api.device_finalize_trial(p_token text,p_command_id uuid,p_status text,p_result jsonb default '{}'::jsonb) returns jsonb language plpgsql security definer set search_path=public as $$
declare did uuid; req public.device_trial_requests%rowtype; sid uuid; org uuid;
begin
 select dt.device_id into did from public.device_tokens dt where dt.token_hash=encode(extensions.digest(p_token,'sha256'),'hex') and dt.revoked_at is null limit 1;
 if did is null then raise exception 'INVALID_DEVICE_TOKEN'; end if;
 select * into req from public.device_trial_requests where command_id=p_command_id and device_id=did and status='queued' for update;
 if not found then return jsonb_build_object('ok',true,'ignored',true); end if;
 select d.org_id into org from public.devices d where d.id=did;
 if p_status='completed' then
   if exists(select 1 from public.rental_sessions rs where rs.device_id=did and rs.status in ('active','paused')) then
     update public.device_trial_requests set status='failed',finished_at=now(),result=jsonb_build_object('error','SESSION_CONFLICT_AFTER_QUEUE') where id=req.id;
     return jsonb_build_object('ok',false,'error','SESSION_CONFLICT_AFTER_QUEUE');
   end if;
   insert into public.rental_sessions(org_id,device_id,code,session_type,started_at,deadline_at,status,metadata) values(org,did,'__TEST10__','free_test',now(),now()+interval '10 minutes','active',jsonb_build_object('source','web_admin','trial_request_id',req.id)) returning id into sid;
   insert into public.billing_transactions(org_id,device_id,rental_session_id,transaction_type,amount,duration_seconds,actor_user_id,reference,metadata) values(org,did,sid,'free_test',0,600,req.created_by,'ADMIN-TRIAL',jsonb_build_object('source','web_admin','trial_request_id',req.id));
   update public.device_trial_requests set status='started',session_id=sid,started_at=now(),finished_at=now(),result=coalesce(p_result,'{}'::jsonb) where id=req.id;
 else
   update public.device_trial_requests set status='failed',finished_at=now(),result=coalesce(p_result,'{}'::jsonb) where id=req.id;
 end if;
 return jsonb_build_object('ok',true,'trial_request_id',req.id,'session_id',sid);
end; $$;
revoke all on function api.device_finalize_trial(text,uuid,text,jsonb) from public; grant execute on function api.device_finalize_trial(text,uuid,text,jsonb) to anon,authenticated;
