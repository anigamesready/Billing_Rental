-- Applied migration: v11_10_admin_control_hardening
-- Server-side target/session validation for the new execution dashboard.
-- The live database contains this migration; this file is the deployment record.

-- See Supabase migration history for the complete applied function bodies.
